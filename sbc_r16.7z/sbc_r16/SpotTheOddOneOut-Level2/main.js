///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 6, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q
var isBgSound = true;
var isEffSound = true;
var currentX, currentY
var currentObj = []
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var ans1, ans2, ans, qCount = 30
var count = 0
///////////////////////////////////////////////////////////////////////GAME SPECIFIC ARRAY//////////////////////////////////////////////////////////////
var qno1 = [];
var choiceArr = []
var chpos = [];
var qno = [];
var rand = []
var choiceChange = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
var btnX = [115, 265, 415, 565, 715, 865, 1015, 1165, 215, 355, 495, 635, 775, 915, 1055, 115, 265, 415, 565, 715, 865, 1015, 1165, 215, 355, 495, 635, 775, 915, 1055]
var btnY = [200, 200, 200, 200, 200, 200, 200, 200, 340, 340, 340, 340, 340, 340, 340, 465, 465, 465, 465, 465, 465, 465, 465, 605, 605, 605, 605, 605, 605, 605]
//register key functions
///////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
///////////////////////////////////////////////////////////////////

function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    callLoader();
    createLoader()
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "SpotTheOddOneOut-Level2/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "introHintImg", src: gameAssetsPath + "Introhintimg.png" },
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "choice2", src: gameAssetsPath + "ChoiceImages2.png" },
            { id: "choice3", src: gameAssetsPath + "ChoiceImages3.png" },
            { id: "questionText", src: questionTextPath + "SpotTheOddOneOut-Level2-QT.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}
//=====================================================================//

function doneLoading1(event) {

    var event = assets[i];
    var id = event.item.id;
    loaderBar.visible = false;
    stage.update();
    if (id == "introHintImg") {
        introHintImg = new createjs.Bitmap(preload.getResult('introHintImg'));
        container.parent.addChild(introHintImg);
        introHintImg.visible = false;
    }
    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }

    if (id == "choice1") {

        var spriteSheet5 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 105, "count": 0, "regY": 50, "width": 105 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice1 = new createjs.Sprite(spriteSheet5);
        choice1.visible = false;
        container.parent.addChild(choice1);
    }
    if (id == "choice2") {

        var spriteSheet5 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice2")],
            "frames": { "regX": 50, "height": 105, "count": 0, "regY": 50, "width": 105 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice2 = new createjs.Sprite(spriteSheet5);
        choice2.visible = false;
        container.parent.addChild(choice2);
    }
    if (id == "choice3") {

        var spriteSheet5 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice3")],
            "frames": { "regX": 50, "height": 105, "count": 0, "regY": 50, "width": 105 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice3 = new createjs.Sprite(spriteSheet5);
        choice3.visible = false;
        container.parent.addChild(choice3);
    }
}


function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 19);
    qno.splice(qno.indexOf(0), 1)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
}
function CreateGameElements() {
    interval = setInterval(countTime, 1000);

    container.parent.addChild(questionText);
    questionText.visible = false


    for (i = 0; i < qCount; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false
        // if (i < 8) {
        //     choiceArr[i].x = 115 + (i * 150)
        //     choiceArr[i].y = 200
        // }
        // else if (i < 15) {
        //     choiceArr[i].x = 215 + ((i - 8) * 140)
        //     choiceArr[i].y = 340
        // } else if (i < 23) {
        //     choiceArr[i].x = 115 + ((i - 15) * 150)
        //     choiceArr[i].y = 465
        // } else {
        //     choiceArr[i].x = 215 + ((i - 23) * 140)
        //     choiceArr[i].y = 605
        // }
        // console.log(choiceArr[i].x + "                 " + choiceArr[i].y)
    }

    choiceChange.sort(randomSort)

    /*if (isQuestionAllVariations) {
        createGameWiseQuestions()
        pickques()
    } else {
        pickques()
    }*/
}

function helpDisable() {
    for (i = 0; i < 6; i++) {
        choiceArr[i].mouseEnabled = true;

    }
}
function helpEnable() {
    for (i = 0; i < 6; i++) {
        choiceArr[i].mouseEnabled = false;

    }


}
//=================================================================================================================================//
function pickques() {
    pauseTimer()
    //for db
    tx = 0;
    qscnt++;
    //db
    cnt++;
    quesCnt++;
    chpos = [];
    currentObj = []
    count = 0
    panelVisibleFn()
    /////////////////////////////////////////////////////////////////////////////
    for (i = 0; i < qCount; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].gotoAndStop(qno[cnt])
        choiceArr[i].visible = true
        choiceArr[i].alpha = 1
        choiceArr[i].name = i
        choiceArr[i].x = btnX[i]
        choiceArr[i].y = btnY[i] - 900

    }
    var rand = range(0, qCount - 1)
    if (choiceChange[cnt] == 1) {
        choiceArr[rand] = choice2.clone()
    } else {
        choiceArr[rand] = choice3.clone()
    }
    container.parent.addChild(choiceArr[rand])
    choiceArr[rand].name = rand
    choiceArr[rand].gotoAndStop(qno[cnt])
    choiceArr[rand].x = btnX[rand]
    choiceArr[rand].y = btnY[rand] - 900
    ans = rand;
    createTween();
}

function createTween() {
    questionText.visible = true;
    questionText.alpha = 0
    createjs.Tween.get(questionText).wait(400).to({ alpha: 1 }, 200);

    var tempVal = 400;
    for (i = 0; i < qCount; i++) {
        choiceArr[i].visible = true
        createjs.Tween.get(choiceArr[i]).wait(tempVal).to({ y: btnY[i] + 30}, 300, createjs.Ease.bounceOut);
        tempVal += 50;
    }

    repTimeClearInterval = setTimeout(AddListenerFn, 2300)
}

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)

    for (i = 0; i < qCount; i++) {
        choiceArr[i].cursor = "pointer";
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].mouseEnabled = true;
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
/*
function enablechoices() {
    for (i = 0; i < 6; i++) {
        choiceArr[i].cursor = "pointer";
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].visible = true;
        choiceArr[i].alpha = 1;
        choiceArr[i].mouseEnabled = true
        choiceArr[i].mouseEnabled = true;
    }

}
*/
function disablechoices() {
    for (i = 0; i < qCount; i++) {
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].visible = false;
        choiceArr[i].alpha = .5;
        choiceArr[i].cursor = "default";
        choiceArr[i].mouseEnabled = false
    }
}

// function onRoll_over(e) {
//     e.currentTarget.alpha = .5;
//     stage.update();
// }

// function onRoll_out(e) {
//     e.currentTarget.alpha = 1;
//     stage.update();
// }

function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    console.log("answer" + uans);
    console.log(ans + " =correct= " + uans)
    gameResponseTimerStop();
    if (ans == uans) {
        getValidation("correct");
        disablechoices();
    } else {
        getValidation("wrong");
        disablechoices();
    }
}



