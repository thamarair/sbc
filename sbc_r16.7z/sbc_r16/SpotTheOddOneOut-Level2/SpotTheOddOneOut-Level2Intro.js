var introArrow, introfingure, introTitle;
var introChoice1TweenArr = []
var introChoiceArr = []
var TempIntroVal;
var highlightTweenArr = []
var cluegotoArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introArrowX = 450, introArrowY = 358;
var introfingureX = 475, introfingureY = 473;
var introChoiceX = [150, 310, 470, 630, 790, 950, 1110, 230, 390, 550, 710, 870, 1030, 150, 310, 470, 630, 790, 950, 1110, 290, 460, 630, 800, 970]
var introChoiceY = [200, 200, 200, 200, 200, 200, 200, 340, 340, 340, 340, 340, 340, 465, 465, 465, 465, 465, 465, 465, 605, 605, 605, 605, 605]
function commongameintro() {
    introTitle = Title.clone()
    introArrow = arrow1.clone()
    introfingure = fingure.clone()
    introquestionText = questionText.clone()
    for (i = 0; i < 25; i++) {
        introChoiceArr[i] = choice1.clone()
    }
    introChoiceArr[15] = choice2.clone()
    container.parent.addChild(introTitle)
    introTitle.visible = true;
    container.parent.addChild(introquestionText);
    introquestionText.visible = true
    container.parent.addChild(introHintImg);
    introHintImg.visible = false
    introHintImg.x = 420
    introHintImg.y = 445
    for (i = 0; i < 25; i++) {
        container.parent.addChild(introChoiceArr[i])
        introChoiceArr[i].visible = false;
        introChoiceArr[i].gotoAndStop(0)
        introChoiceArr[i].x = introChoiceX[i]
        introChoiceArr[i].y = introChoiceY[i]
    }

    introquestionText.alpha = 0;
    createjs.Tween.get(introquestionText).to({ alpha: 1 }, 1000).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {
    var introtempVal = 0;
    for (i = 0; i < 25; i++) {
        introChoiceArr[i].visible = true
        if (i == 24) {
            createjs.Tween.get(introChoiceArr[i])
            .wait(introtempVal)
            .to({ y: introChoiceY[i] + 33  }, 300, createjs.Ease.bounceOut).wait(400).call(handleComplete2_1);
        } else {
            createjs.Tween.get(introChoiceArr[i]).wait(introtempVal).to({ y: introChoiceY[i] + 33 }, 300, createjs.Ease.bounceOut);
        }
        introtempVal += 50;
    }
}


function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    choiceTween()
}
function choiceTween() {
    introChoiceArr[15].visible=false
    introHintImg.visible = true
    introHintImg.alpha=0
    createjs.Tween.get(introHintImg)
    .to({ alpha: 1, scaleX: 1, scaleY: 1 }, 400)
    .to({ scaleX: 1.05, scaleY: 1.05 }, 400)
    .to({ scaleX: 1, scaleY: 1 }, 400)
    .to({ scaleX: 1.15, scaleY: 1.15 }, 400)
    .wait(500).call(handleComplete3_1);
}
function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    setArrowTween()
}
function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])

        highlightTweenArr[0] = createjs.Tween.get(introArrow)
        .to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)


    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200)
            .call(this.onComplete2)
        //setTimeout(setstarAnimation, 1000)
    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();


    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        console.log("///setcallDelat=====+");
        setTimeout(setCallDelay, 500)
    }

}

function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    container.parent.removeChild(introquestionText)
    introquestionText.visible = false
    container.parent.removeChild(introHintImg)
    introHintImg.visible = false

    for (i = 0; i < 25; i++) {
        container.parent.removeChild(introChoiceArr[i])
        introChoiceArr[i].visible = false;
    }

}