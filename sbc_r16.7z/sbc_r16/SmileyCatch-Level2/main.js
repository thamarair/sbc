///////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 7, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg, IntroImg, IntroImg1;
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q
var isBgSound = true;
var isEffSound = true;
var currentX, currentY
var currentObj = []
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;

var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
///////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES//////////////////////////////////////////////////////////
var choice1, chHolder, questionText, quesInterval;
var tempuans = "", tempans = "", correctCnt, rand, temp;

//////////////////////////////////////////////////////==========GAME SPECIFIC ARRAYS============/////////////////////////////////////////////////////////////
var qno = [];
var chpos = []
var choiceArr = [];
var posXarr = [, 470, 640, 560, 475, 810, 945, 325, 410, 800, 870, 195, 100, 270, 1015, 1085, 715, 640, 1185]
var posYarr = [, 260, 240, 420, 605, 605, 335, 335, 455, 270, 455, 425, 570, 560, 555, 410, 425, 565, 535]
//register key functions

/////////////////////////////////////////////////////////=========BROWSER SUPPORT============////////////////////////////////////////////////////////////////

window.onload = function (e) {
    checkBrowserSupport();
}

//////////////////////////////////////////////////////////=========INITIALIZATION=============///////////////////////////////////////////////////////////////



function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    callLoader();
    createLoader();
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////
    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */
    assetsPath = "assets/";
    gameAssetsPath = "SmileyCatch-Level2/";
    soundpath = "VP/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "IntroImg1", src: gameAssetsPath + "IntroImg1.png" },
            { id: "IntroImg", src: gameAssetsPath + "IntroImg.png" },
            { id: "chHolder", src: gameAssetsPath + "chHolder.png" },
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "questionText", src: questionTextPath + "SmileyCatch-Level2-QT.png" },
            { id: "questionText1", src: questionTextPath + "SmileyCatch-Level2-QT1.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}
////////////////////////////////////////////////////////////==========PRELOADER===========/////////////////////////////////////////////////////////////////
function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;
    if (id == "IntroImg1") {
        IntroImg1 = new createjs.Bitmap(preload.getResult('IntroImg1'));
        container.parent.addChild(IntroImg1);
        IntroImg1.visible = false;
    }
    if (id == "IntroImg") {
        IntroImg = new createjs.Bitmap(preload.getResult('IntroImg'));
        container.parent.addChild(IntroImg);
        IntroImg.visible = false;
    }
    if (id == "choice1") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 100, "count": 0, "regY": 50, "width": 100 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        choice1 = new createjs.Sprite(spriteSheet2);
        choice1.visible = false;
        container.parent.addChild(choice1);
    };
    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
    if (id == "questionText1") {
        questionText1 = new createjs.Bitmap(preload.getResult('questionText1'));
        container.parent.addChild(questionText1);
        questionText1.visible = false;
    }
    if (id == "chHolder") {
        chHolder = new createjs.Bitmap(preload.getResult('chHolder'));
        container.parent.addChild(chHolder);
        chHolder.visible = false;
    }
}



function tick(e) {

    stage.update();

}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////

function handleClick(e) {
    qno = between(0, 29)
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
}

////////////////////////////////////////////////////////////=========GAME ELEMENTS CREATION===========//////////////////////////////////////////////////////

function CreateGameElements() {
    interval = setInterval(countTime, 1000);

    container.parent.addChild(questionText);
    questionText.visible = false;
    container.parent.addChild(questionText1);
    questionText1.visible = false;

    container.parent.addChild(chHolder);
    chHolder.visible = false;
    //  
    for (i = 1; i <= 18; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false;
        choiceArr[i].x = posXarr[i]
        choiceArr[i].y = posYarr[i]
    }

    // if (isQuestionAllVariations) {
    // } else {
    // }
}

////////////////////////////////////////////////////////////TWEEN MC////////////////////////////////////////////////////////////////////////////////////

/*var getTweenMc = new createjs.MovieClip()

container.parent.addChild(getTweenMc)

getTweenMc.timeline.addTween(createjs.Tween.get(this["choice" + i]).to({ scaleX: 0.96, scaleY: 0.96}, 24).to({ scaleX: 1, scaleY: 1 }, 25).wait(1));

*/

/////////////////////////////////////////////////////////=======HELP POP-UP CONTROL=======//////////////////////////////////////////////////////////////

function helpDisable() {
    for (i = 1; i <= 15; i++) {
        choiceArr[i].mouseEnabled = false;
    }
}
function helpEnable() {
    for (i = 1; i <= 15; i++) {
        choiceArr[i].mouseEnabled = true;
    }
}
//////////////////////////////////////////////////////////===========GAME LOGIC============///////////////////////////////////////////////////////////////

function pickques() {
    //======================================================RESET VARIABLES=====================================================================    
    pauseTimer()
    //for db
    tx = 0;
    qscnt++;
    //db   
    cnt++;
    quesCnt++;
    correctCnt = 0;
    tempuans = "";
    tempans = "";
    chpos = []
    panelVisibleFn()
    //===========================================================LOGIC AREA============================================================================
     questionText.visible = false;
     questionText1.visible = false;
     temp = between(1, 29)
     rand = between(1, 18)
     // quesInterval = setInterval(quesDisp, 5000);
     for (i = 1; i <= 18; i++) {
         if (rand[1] == i || rand[2] == i|| rand[3] == i) {
             choiceArr[i].gotoAndStop(0)
             choiceArr[i].name = 0;
         } else {
             choiceArr[i].gotoAndStop(temp[i])
             choiceArr[i].name = temp[i];
         }
     }
     ans = 0;
     createTween();
}


function createTween() {
    questionText.visible = true;
    questionText.alpha = 0
    createjs.Tween.get(questionText).wait(100).to({ alpha: 1 }, 200);

    chHolder.visible = true;
    chHolder.y = 3000;
    createjs.Tween.get(chHolder).wait(200).to({ y: 0 }, 1000);

    var tempVal1 = 900;
    for (i = 1; i <= 18; i++) {
        choiceArr[i].alpha = 0
        createjs.Tween.get(choiceArr[i]).wait(tempVal1).to({ visible: true, alpha: .5, rotation: 180, scaleX: .3, scaleY: .3 }, 300)
            .to({ alpha: .5, rotation: 90, scaleX: .7, scaleY: .7 }, 300)
            .to({ alpha: 1, rotation: 360, scaleX: 1, scaleY: 1 }, 300)
    }

    setTimeout(createTween1, 5000);

}

function createTween1() {
    for (i = 1; i <= 15; i++) {
        choiceArr[i].gotoAndStop(40)
        choiceArr[i].alpha = 1
    }

    questionText.visible = false;
    questionText1.visible = true;
    questionText1.alpha = 0
    createjs.Tween.get(questionText1).wait(100).to({ alpha: 1 }, 200);

    for (i = 1; i <= 18; i++) {
        choiceArr[i].visible = true;
        choiceArr[i].gotoAndStop(30)
    }

    repTimeClearInterval = setTimeout(AddListenerFn, 600)
}

/////////////////////////////////////////////////////////========CHOICES ENABLE/DISABLE=======////////////////////////////////////////////////////////////

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    for (i = 1; i <= 18; i++) {
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].cursor = "pointer";
        choiceArr[i].mouseEnabled = true;
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
    stage.update();
}

function disablechoices() {
    for (i = 1; i <= 18; i++) {
        choiceArr[i].removeEventListener("click", answerSelected)
        choiceArr[i].cursor = "default";
        choiceArr[i].mouseEnabled = false;
    }
    stage.update();
}
////////////////////////////////////////////////////////////=======MOUSE EVENTLISTENERS=======///////////////////////////////////////////////////////////////
function onRoll_over(e) {
    e.currentTarget.alpha = .5;
    stage.update()
}
function onRoll_out(e) {
    e.currentTarget.alpha = 1;
    stage.update();
}
//////////////////////////////////////////////////////////========ANSWER VALIDATION========//////////////////////////////////////////////////////////////////
/*  Always "ans" and "uans" must be present for validation. They must not be changed.  */

function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();
    e.currentTarget.visible = false

    if (uans == ans) {
        correctCnt++
        if (correctCnt == 3) {
            getValidation("correct");
            disablechoices();
        }
    } else {
        getValidation("wrong");
        disablechoices();
    }

}
