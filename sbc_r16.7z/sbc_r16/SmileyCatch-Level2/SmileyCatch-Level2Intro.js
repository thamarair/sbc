var introArrow, introfingure, introTitle, introquestionText, introquestionText1, introHolder;
var introChoiceArr = []
var highlightTweenArr = []
var TempIntroVal;
var setIntroCnt = 0
var removeIntraval = 0
var introChoiceX = [, 470, 640, 560, 475, 810, 945, 325, 410, 800, 870, 195, 100, 270, 1015, 1085, 715, 640, 1185]
var introChoiceY = [, 260, 240, 420, 605, 605, 335, 335, 455, 270, 455, 425, 570, 560, 555, 410, 425, 565, 535]
var ArrowXArr = [575, 340,285], FingXArr = [590, 360,305]
var ArrowYArr = [300, 225,440], FingYArr = [405, 320,540]
function commongameintro() {
    TempIntroVal = -1;
    introTitle = Title.clone()
    introArrow = arrow1.clone()
    introfingure = fingure.clone()

    for (i = 1; i <= 18; i++) {
        introChoiceArr[i] = choice1.clone()
    }

    introHolder = chHolder.clone()
    introquestionText = questionText.clone()
    introquestionText1 = questionText1.clone()

    container.parent.addChild(introTitle)
    introTitle.visible = true;

    container.parent.addChild(IntroImg)
    IntroImg.visible = false;
    IntroImg.x = 340; IntroImg.y = 180
    container.parent.addChild(IntroImg1)
    IntroImg1.visible = false;
    IntroImg1.x = 340; IntroImg1.y = 200

    container.parent.addChild(introquestionText);
    introquestionText.visible = true;
    container.parent.addChild(introquestionText1);
    introquestionText1.visible = false;

    container.parent.addChild(introHolder)
    introHolder.visible = false;

    for (i = 1; i <= 18; i++) {
        container.parent.addChild(introChoiceArr[i])
        introChoiceArr[i].visible = false;
        introChoiceArr[i].x = introChoiceX[i]
        introChoiceArr[i].y = introChoiceY[i]
        introChoiceArr[i].gotoAndStop(i);
        if (i == 3 || i == 7 || i == 13) {
            introChoiceArr[i].gotoAndStop(0);
        }
    }

    introquestionText.alpha = 0;
    createjs.Tween.get(introquestionText).to({ alpha: 1 }, 1000).call(handleComplete1_1);

}

function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    quesTween()
}

function quesTween() {
    introHolder.visible = true;
    introHolder.y = 3000;
    createjs.Tween.get(introHolder).wait(50).to({ y: 0 }, 1000).wait(2500).call(handleComplete2_1);

    var introTempVal1 = 800;
    for (i = 1; i <= 18; i++) {
        introChoiceArr[i].alpha = 0
        createjs.Tween.get(introChoiceArr[i]).wait(introTempVal1).to({ visible: true, alpha: .5, rotation: 180, scaleX: .3, scaleY: .3 }, 300)
            .to({ alpha: .5, rotation: 90, scaleX: .7, scaleY: .7 }, 300)
            .to({ alpha: 1, rotation: 360, scaleX: 1, scaleY: 1 }, 300)
    }
}
function handleComplete2_1() {
    createjs.Tween.removeAllTweens();
    choiceTween()
}
function choiceTween() {
    var introvalX = [, 430, 500, 580, 650, 690, 430, 500, 580, 650, 690, 430, 500, 580, 650, 690, 430, 500, 580, 650, 500, 580, 650]

    for (i = 1; i <= 18; i++) {
        createjs.Tween.get(introChoiceArr[i]).wait(50).to({ x: introvalX[i], y: 290, scaleX: .6, scaleY: .6 }, 500).to({ alpha: 1 })
    }
    introHolder.alpha = .5

    IntroImg1.visible = true;
    IntroImg1.alpha = 0
    createjs.Tween.get(IntroImg1).to({ alpha: 1, scaleX: .9, scaleY: .9 }, 300)
        .to({ scaleX: 1, scaleY: 1 }, 300).call(handleComplete3_1);

}

function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    choiceTween1()
}
function choiceTween1() {
    for (i = 1; i <= 18; i++) {
        introChoiceArr[i].visible = false;
    }
    introHolder.visible = false
    IntroImg1.visible = false;
    IntroImg.visible = true;
    IntroImg.scaleX = IntroImg.scaleY = .8
    createjs.Tween.get(IntroImg).to({ alpha: 1, scaleX: .95, scaleY: .95 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 500).to({ scaleX: .95, scaleY: .95 }, 500)
        .to({ scaleX: 1, scaleY: 1 }, 1000);

    createjs.Tween.get(IntroImg).wait(3000).to({ scaleX: .65, scaleY: .65, x: 20, y: 135 }, 500).wait(500).call(handleComplete4_1);

}

function handleComplete4_1() {
    createjs.Tween.removeAllTweens();
    choiceTween2()
}
function choiceTween2() {
    introquestionText.visible = false
    introquestionText1.visible = true;
    introquestionText1.alpha = 0
    createjs.Tween.get(introquestionText1).wait(200).to({ alpha: 1 }, 200).wait(1000).call(handleComplete5_1);

    introHolder.visible = true
    introHolder.alpha = 1
    introHolder.x = 45;
    introHolder.y = 10;
    for (i = 1; i <= 18; i++) {
        introChoiceArr[i].visible = true;
        introChoiceArr[i].gotoAndStop(30)
        introChoiceArr[i].x = introChoiceX[i] + 45
        introChoiceArr[i].y = introChoiceY[i] + 10
        introChoiceArr[i].scaleX = introChoiceArr[i].scaleY = 1
    }

}
function handleComplete5_1() {
    createjs.Tween.removeAllTweens();
    setArrowTween()
}
function setArrowTween() {
    TempIntroVal++;

    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.addChild(introArrow);

        introArrow.visible = true;
        introfingure.visible = false;
        introArrow.x = ArrowXArr[TempIntroVal];
        introArrow.y = ArrowYArr[TempIntroVal];
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: ArrowYArr[TempIntroVal] + 10 }, 350).to({ y: ArrowYArr[TempIntroVal] }, 350).to({ y: ArrowYArr[TempIntroVal] + 10 }, 350)
            .to({ y: ArrowYArr[TempIntroVal] }, 350).to({ y: ArrowYArr[TempIntroVal] + 10 }, 350).to({ y: ArrowYArr[TempIntroVal] }, 350).wait(400).call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
   
        introfingure.visible = true;
        introfingure.x = FingXArr[TempIntroVal];
        introfingure.y = FingYArr[TempIntroVal];
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        if (TempIntroVal == 2) {
            highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: FingXArr[TempIntroVal] }, 350).to({ x: FingXArr[TempIntroVal] - 15 }, 350)
                .to({ x: FingXArr[TempIntroVal] }, 350).to({ x: FingXArr[TempIntroVal] - 15 }, 350).wait(200).call(this.onComplete2)
        }
        else {
            highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: FingXArr[TempIntroVal] }, 350).to({ x: FingXArr[TempIntroVal] - 15 }, 350)
                .to({ x: FingXArr[TempIntroVal] }, 350).to({ x: FingXArr[TempIntroVal] - 15 }, 350).wait(200).call(handleComplete5_1)

        }
    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();


    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        console.log("///setcallDelat=====+");
        setTimeout(setCallDelay, 500)
    }

}

function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
 
    container.parent.removeChild(introquestionText)
    introquestionText.visible = false
    container.parent.removeChild(introquestionText1)
    introquestionText1.visible = false
    container.parent.removeChild(introHolder)
    introHolder.visible = false
    container.parent.removeChild(IntroImg)
    IntroImg.visible = false
    container.parent.removeChild(IntroImg1)
    IntroImg1.visible = false
    for (i = 1; i <= 18; i++) {
        container.parent.removeChild(introChoiceArr[i])
        introChoiceArr[i].visible = false
    }
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}