var introTitle, introQuestxt, introQues, introArrow, introfingure, introHolder
var introChoiceArr = []
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introArrowX = 710, introArrowY = 80;
var introfingureX = 770, introfingureY = 200;
var vno = []
var inc = 0, j = 0
var introPosX = [160, 365, 575, 775, 990, 160, 365, 575, 775, 990, 160, 365, 575, 775, 990, 160, 365, 575, 775, 990,1195,1195,1195,1195]
var introPosY = [195, 195, 195, 195, 195, 325, 325, 325, 325, 325, 457, 457, 457, 457, 457, 595, 595, 595, 595, 595,195,325,457,595]
function commongameintro() {
    introTitle = Title.clone()
    introArrow = arrow1.clone()
    introfingure = fingure.clone()


    introQuestxt = questionText.clone();
    for (i = 0; i < 24; i++) {
        introChoiceArr[i] = choice1.clone();
    }
    introChoiceArr[3] = choice2.clone();

    container.parent.addChild(introTitle)
    introTitle.visible = true;


    for (i = 0; i < 24; i++) {
        container.parent.addChild(introChoiceArr[i]);
        introChoiceArr[i].visible = false;
        introChoiceArr[i].gotoAndStop(0);
        introChoiceArr[i].x = introPosX[i]-75;
        introChoiceArr[i].y = introPosY[i]+20;
        introChoiceArr[i].scaleX = introChoiceArr[i].scaleY = 1.1
    }

    container.parent.addChild(introQuestxt);
    introQuestxt.visible = true;
    introQuestxt.y = -20
    introQuestxt.alpha = 0;
    createjs.Tween.get(introQuestxt).wait(100).to({ alpha: 1 }, 500).call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
       
    choiceTween()
    }
}
function choiceTween() {
    var introTemp = 100
    for (i = 0; i < 24; i++) {
        introChoiceArr[i].x = -1000;
        introChoiceArr[i].alpha = 0;
        if (i == 19) {
            createjs.Tween.get(introChoiceArr[i]).wait(introTemp).to({ visible: true, alpha: 1, x: introPosX[i]-50 }, 900, createjs.Ease.bounceIn).wait(1000).call(handleComplete3_1);
        }
        else {
            createjs.Tween.get(introChoiceArr[i]).wait(introTemp).to({ alpha: 1, x: introPosX[i]-50}, 1000, createjs.Ease.bounceIn);
        }
        introChoiceArr[i].visible = true;
        introTemp += 50;
    }
}

function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        ansTween()
    }
}
function ansTween() {

    createjs.Tween.get(introChoiceArr[3]).wait(200).to({ scaleX: 1, scaleY: 1 }, 300).to({ scaleX: 1.1, scaleY: 1.1 }, 300)
        .to({ scaleX: 1, scaleY: 1 }, 300).to({ scaleX: 1.1, scaleY: 1.1 }, 300)
        .to({ scaleX: 1, scaleY: 1 }, 300).to({ scaleX: 1.15, scaleY: 1.15 }, 300).call(handleComplete4_1)
}
function handleComplete4_1() {

    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        setArrowTween()
    }

}

function setArrowTween() {
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);

        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).wait(400).call(this.onComplete1)

    }

}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
  
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure).to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).to({ x: introfingureX }, 350).to({ x: introfingureX - 15 }, 350).wait(200).call(this.onComplete2)

    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }
  
    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        setTimeout(setCallDelay, 500)
    }


}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {
  
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false
    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false

    for (i = 0; i < 24; i++) {
        container.parent.removeChild(introChoiceArr[i]);
        introChoiceArr[i].visible = false;
    }
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }


}