///////////////////////////////////////////////////-------Common variables--------------/////////////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 3, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;
var mc, mc1, mc2, mc3, mc4, mc5, startMc, questionInterval = 0;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc, gameIntroAnimMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var bg;
var BetterLuck, Excellent, Nice, Good, Super, TryAgain;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;
var isBgSound = true;
var isEffSound = true;
var currentX, currentY;
var currentObj = []
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both';
var isScale = true;
var scaleType = 1;
var px = [100, 320, 540, 760, 980];
var py = [295, 295, 295, 295, 490, 490];
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;

/////////////////////////////////////////////////////////////////////////GAME SPECIFIC VARIABLES/////////////////////////////////////////////////////////
var chHolderMc, choice1, choice2, choice3, question;

//////////////////////////////////////////////////////==========GAME SPECIFIC ARRAYS============/////////////////////////////////////////////////////////////
var qno = [];
var choiceArr = []
var posXarr = [240, 435, 635, 825, 1015, 240, 435, 635, 825, 1015, 240, 435, 635, 825, 1015, 240, 435, 635, 825, 1015, 1195, 1195, 1195, 1195]
var posYarr = [190, 190, 190, 190, 190, 320, 320, 320, 320, 320, 452, 452, 452, 452, 452, 590, 590, 590, 590, 590,190,320,452,590]
var chpos = [];
var rand
//register key functions
/////////////////////////////////////////////////////////=========BROWSER SUPPORT============////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
//////////////////////////////////////////////////////////=========INITIALIZATION=============///////////////////////////////////////////////////////////////

function init() {

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    callLoader();
    createLoader();
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);

    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "ShapeShifters-Level2/";
    soundpath = "VP/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "choice1", src: gameAssetsPath + "ChoiceImages1.png" },
            { id: "choice2", src: gameAssetsPath + "ChoiceImages2.png" },           
            { id: "questionText", src: questionTextPath + "ShapeShifters-Level2-QT.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}

////////////////////////////////////////////////////////////==========PRELOADER===========/////////////////////////////////////////////////////////////////
function doneLoading1(event) {

    var event = assets[i];
    var id = event.item.id;
    console.log(id)


    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }

    if (id == "choice1") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 115, "count": 0, "regY": 50, "width": 115 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice1 = new createjs.Sprite(spriteSheet1);
        choice1.visible = false;
        container.parent.addChild(choice1);
    };

    if (id == "choice2") {
        var spriteSheet1 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice2")],
            "frames": { "regX": 50, "height": 115, "count": 0, "regY": 50, "width": 115 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice2 = new createjs.Sprite(spriteSheet1);
        choice2.visible = false;
        container.parent.addChild(choice2);

    };
}

function tick(e) {
    stage.update();
}


/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////
function handleClick(e) {
    qno = between(0, 9)
    CreateGameStart();
    if (gameType == 0) {
        CreateGameElements();
        getStartQuestion();
    } else {
        //for db
        getdomainpath();
        //end
    }
}

////////////////////////////////////////////////////////////=========GAME ELEMENTS CREATION===========//////////////////////////////////////////////////////
function CreateGameElements() {

    interval = setInterval(countTime, 1000);  

    container.parent.addChild(questionText);
    questionText.visible = false;
    questionText.y = -20
    container.parent.addChild(choice2)
    choice2.visible = false;
    choice2.scaleX = choice2.scaleY = 1.1

    for (i = 0; i < 24; i++) {
        choiceArr[i] = choice1.clone()
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false;
        choiceArr[i].y = posYarr[i]+7
        choiceArr[i].x = posXarr[i] -10
        choiceArr[i].scaleX = choiceArr[i].scaleY = 1.1
    }

}
/////////////////////////////////////////////////////////=======HELP POP-UP CONTROL=======//////////////////////////////////////////////////////////////
function helpDisable() {
    for (i = 0; i < 24; i++) {
        choiceArr[i].mouseEnabled = false;
    }
    choice2.mouseEnabled = false
}

function helpEnable() {
    for (i = 0; i < 24; i++) {
        choiceArr[i].mouseEnabled = true;
    }
    choice2.mouseEnabled = true
}
//////////////////////////////////////////////////////////===========GAME LOGIC============///////////////////////////////////////////////////////////////
function pickques() {
    pauseTimer()
    cnt++;
    //for db
    tx = 0;
    qscnt++;
    //db
    quesCnt++;
    chpos = [];
    panelVisibleFn();
    //=================================================================================================================================// 
    for (i = 0; i < 24; i++) {
        choiceArr[i].gotoAndStop(qno[cnt])
        choiceArr[i].visible = false;
        choiceArr[i].name = "ch" + i
    }

    ans = "ch20";

    rand = range(0, 19)

    choice2.gotoAndStop(qno[cnt])
    choice2.name = "ch" + 20
    choice2.visible = false;
    choiceArr[rand].visible = false;
    choice2.x = choiceArr[rand].x
    choice2.y = choiceArr[rand].y

    createTween();
}
function createTween() {
    questionText.visible = true;
    questionText.alpha = 0;
    createjs.Tween.get(questionText).wait(100).to({ alpha: 1 }, 1000);

   
    var temp = 400
    for (i = 0; i < 24; i++) {
        if (i == rand) {
            choiceArr[rand].visible = false;
            choice2.visible = true;
            choice2.x = -1000
            createjs.Tween.get(choice2).wait(temp).to({ visible: true, alpha: 1, x: posXarr[rand]-80}, 900, createjs.Ease.bounceIn);
        }
        else {
            choiceArr[i].visible = true;
            choiceArr[i].x = -1000;
            choiceArr[i].alpha = 0;
            createjs.Tween.get(choiceArr[i]).wait(temp).to({ alpha: 1, x: posXarr[i]-80 }, 1000, createjs.Ease.bounceIn);
        }
        temp += 50;
    }
    repTimeClearInterval = setTimeout(AddListenerFn, 2100)
}
/////////////////////////////////////////////////////////========CHOICES ENABLE/DISABLE=======////////////////////////////////////////////////////////////

function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
    for (i = 0; i < 24; i++) {
        choiceArr[i].mouseEnabled = true;
        choiceArr[i].addEventListener("click", answerSelected);
        choiceArr[i].cursor = "pointer";
    }
    choice2.mouseEnabled = true;
    choice2.addEventListener("click", answerSelected);
    choice2.cursor = "pointer";

    stage.update();
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {
    for (i = 0; i < 24; i++) {
        choiceArr[i].removeEventListener("click", answerSelected);
        choiceArr[i].cursor = "default";
        choiceArr[i].mouseEnabled = false;
        choiceArr[i].visible = false;
    }

    choice2.removeEventListener("click", answerSelected);
    choice2.cursor = "default";
    choice2.mouseEnabled = false;
    choice2.visible = false;
    stage.update();
}

///////////////////////////////////////////////////////////========ANSWER VALIDATION========//////////////////////////////////////////////////////////////////

/*  Always "ans" and "uans" must be present for validation. They must not be changed.  */

function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();
    // pauseTimer();
    if (ans == uans) {
        getValidation("correct");
    } else {
        getValidation("wrong");
    }
    disablechoices();
}