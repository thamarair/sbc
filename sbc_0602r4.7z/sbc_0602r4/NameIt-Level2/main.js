//////////////////////////////////////////////////////===========COMMON GAME VARIABLES==========/////////////////////////////////////////////////////////////



var messageField;		//Message display field

var assets = [];

var j = 1;

var cnt = -1, qscnt = -1, ans, bg, uans, len, cluetext, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, maxCount = 10, choiceCnt = 4, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;

var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;

var mc, startMc, ch = 0, n = 0, noMc, yesMc, background1;

var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc;

var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;

var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;

var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q

var isBgSound = true;

var isEffSound = true;

var isOlderBrowser = false;

var isLandOrientation = false;

var url = "";

var nav = "";

var isResp = true;

var respDim = 'both'

var isScale = true

var scaleType = 1;

var lastW, lastH, lastS = 1;

var borderPadding = 10, barHeight = 20;

var loadProgressLabel, progresPrecentage, loaderWidth;

////////////////////////////////////////////////////==========GAME SPECIFIC VARIABLES============/////////////////////////////////////////////////////////////
// var Questio


// //////////////////////////////////////////////////////==========GAME SPECIFIC ARRAYS============/////////////////////////////////////////////////////////////

var questionArr =["ENGLISH","COMPUTER","MATTER","CHECKED","COUNTRY","INCHES","REACHED","SCIENCE","SCREAM","RAISE",
"FATHER","CURRENT","ELECTRIC","THOUGHT","DISTANCE","HUNDRED","DIFFERENCE","LEAST","PRODUCT","QUOTIENT",
"SOMETHING","PROPERTY","DECIMAL","SPEECH","DIRECTION","TRAVEL","FRACTION","TOGETHER","IMPORTANT","CHILDREN",
"DESERT","OPERATION","DESTROY","RELATION","FOUNDATION","GROUND","DISAPPEAR","INTEGER","PREDICT","UNDERSTOOD",
"CARPET","APPEARANCE","ATTRIBUTES","AIRPLANE","MOUNTAINS","PLANETS","PYRAMID","POSITION","DERIVE","GENERAL" ]
var answerArr =["shine","metro","treat","cheek","count","since","heard","scene","scare","arise","earth",
"cuter","litre","tough","dance","under","fence","steal","proud","quiet","stone","retry","medal","sheep",
"tonic","later","actor","there","train","hired","trees","point","store","trial","found","round","paper",
"enter","price","nurse","react","peace","start","plain","minus","plate","dairy","spoon","drive","learn"]
var clueArr=["Give out a bright light","An underground railway system","Try to cure","Either side of the face below the eye",
"The total number","Period between the time mentioned and the present","Perceive with the ear","Site or location","Frighten",
"Get or stand up","The planet on which we live","Lovable","A unity of measuring liquids","Hard","Move in a quick and lively way to music",
"Below","A barrier enclosing an area of ground","Take without permission ","Feeling pleasure as a result of one's own achievements",
"No noise","Hard rock","Try again","Honour or badge","A domestic animal","A medicinal substance","Good bye for the present","Performer, artist",
"That place or position","Teach or coach","Rented","Woody plants","A dot","Keep for future use",
"Test or try out","Discover a thing","Shape like a circle","Thin sheets","Come or go into","Cost",
"A person to care of sick people","Respond","Calm, quiet","Begin","Simple, clear","Subtraction",
"A flat dish","Milk products","Long handle used for eating, stirring","Control the direction and speed of a vehicle","Acquire knowledge"]
var alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
var tempuans = "";
var qno = [];
var choiceArr = []
var optionArr = []
var ansArr = []
var tweenMcArr = []
/////////////////////////////////////////////////////////=========BROWSER SUPPORT============////////////////////////////////////////////////////////////////

//register key functions

window.onload = function (e) {

    checkBrowserSupport();

}

//////////////////////////////////////////////////////////=========INITIALIZATION=============///////////////////////////////////////////////////////////////

function init() {

    console.log("innt")



    canvas = document.getElementById("gameCanvas");

    stage = new createjs.Stage(canvas);

    container = new createjs.Container();

    stage.addChild(container)

    createjs.Ticker.addEventListener("tick", stage);

    callLoader();

    createLoader();

    createCanvasResize()



    stage.update();

    stage.enableMouseOver(40);



    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////



    /*Always specify the following terms as given in manifest array. 

         1. choice image name as "ChoiceImages1.png"

         2. question text image name as "questiontext.png"

     */

    assetsPath = "assets/";
    gameAssetsPath = "NameIt-Level2/";
    soundpath = "LI/"


    var success = createManifest();

    if (success == 1) {

        manifest.push(
            { id: "choice1", src: gameAssetsPath + "choiceImages1.png" },
            { id: "btn", src: gameAssetsPath + "btnImages1.png" },
            
            { id: "questionText", src: questionTextPath + "NameIt-Level2-QT.png" },
          
        )

        preloadAllAssets()
        stage.update();
    }
}
function doneLoading1(event) {

    var event = assets[i];
    var id = event.item.id;
 


    if (id == "choice1") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 100, "count": 0, "regY": 50, "width": 100 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });

        choice1 = new createjs.Sprite(spriteSheet2);
        choice1.visible = false;
        container.parent.addChild(choice1);
        choice1.x = 400; choice1.y = 400;
    };

    if (id == "btn") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("btn")],
            "frames": { "regX": 50, "height": 119, "count": 0, "regY": 50, "width": 119 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        btn = new createjs.Sprite(spriteSheet2);
        btn.visible = false;
        container.parent.addChild(btn);
    };
    
    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }

}



function tick(e) {

    stage.update();

}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////

function handleClick(e) {
    qno = between(0, 49);
    console.log("qno= " + qno)
    qno.sort(randomSort);
    CreateGameStart()

    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }

}

////////////////////////////////////////////////////////////=========GAME ELEMENTS CREATION===========//////////////////////////////////////////////////////


function CreateGameElements() {

    interval = setInterval(countTime, 1000);


    cluetext = new createjs.Text("", "44px lato-Bold", "black")
    container.parent.addChild(cluetext)
    cluetext.textAlign = "center";
    cluetext.textBaseline = "middle";
    cluetext.x = 633
    cluetext.y = 392
    //startMc.timeline.addTween(createjs.Tween.get(startBtn).to({ scaleX: 0.9, scaleY: 0.9 }, 24).to({ scaleX: 1, scaleY: 1 }, 25).wait(1));
    for (i = 1; i <= maxCount; i++) {
        optionArr[i] = choice1.clone();
        container.parent.addChild(optionArr[i])
        optionArr[i].visible = false;
        optionArr[i].x = 100 + (i * 60);
        optionArr[i].y = 555
         optionArr[i].scaleX= optionArr[i].scaleY=.75
        // var getTweenMc = new createjs.MovieClip()
        // container.parent.addChild(getTweenMc)
        // getTweenMc.timeline.addTween(createjs.Tween.get(optionArr[i]).to({ scaleX: 0.96, scaleY: 0.96 }, 24).to({ scaleX: 1, scaleY: 1 }, 25).wait(1));
    }

    for (i = 1; i <= 5; i++) {
        choiceArr[i] = btn.clone();
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false;
       choiceArr[i].x = 410 + (i * 75);
        choiceArr[i].y = 260
          choiceArr[i].scaleX = choiceArr[i].scaleY = .6
    }
    questionText.visible = false;
    questionText.x = 0
    questionText.y = 0
    container.parent.addChild(questionText);

}

/////////////////////////////////////////////////////////=======HELP POP-UP CONTROL=======//////////////////////////////////////////////////////////////

function helpDisable() {
    for (i = 1; i <= len; i++) {
        optionArr[i].mouseEnabled = false;
    }
}



function helpEnable() {
    for (i = 1; i <= len; i++) {
        optionArr[i].mouseEnabled = true;
    }
}

//////////////////////////////////////////////////////////===========GAME LOGIC============///////////////////////////////////////////////////////////////

function pickques() {

    //======================================================RESET VARIABLES=====================================================================    
    pauseTimer()
    tx = 0;
    clk = 0;
    cnt++; qscnt++;
    quesCnt++;
    ansArr = [];
    panelVisibleFn()
    //===========================================================LOGIC AREA============================================================================\
    tempuans = "";
    console.log(questionArr)
    cluetext.text = clueArr[qno[cnt]];
    cluetext.visible = false;
    question = questionArr[qno[cnt]];
    len = question.length;
    console.log("length " + len)

    for (i = 0; i < len; i++) {
        var char = question.charAt(i);
        var index = alphabet.indexOf(char)
        optionArr[i + 1].gotoAndStop(index)
        optionArr[i + 1].visible = false;
        optionArr[i + 1].name = char
    }

      console.log("clueArr[qno[cnt]].length" + clueArr[qno[cnt]].length)
         if(clueArr[qno[cnt]].length >= 25){
            cluetext.font = "bold 40px lato-bold";
            console.log(" it resized")
          
         } 
           else{
              console.log(" it not resized")
            cluetext.font = "bold 40px lato-bold";           
        }
    ans = answerArr[qno[cnt]];
    console.log("ans" + ans)
    for (i = 0; i < 5; i++) {
        ansArr.push(ans.charAt(i).toString().toUpperCase());
        var index = alphabet.indexOf(ansArr[i])
        choiceArr[i + 1].gotoAndStop(index)
        choiceArr[i + 1].visible = false;
    }

    //===========================================================End LOGIC AREA============================================================================\


    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();

}

//===================================================================================================================================================================//
function createTween() {
    questionText.visible = true;
    questionText.alpha = 0
    questionText.scaleX = .99
    createjs.Tween.get(questionText).wait(100).to({ alpha: 1 }, 200)

   


    cluetext.visible = true;
    cluetext.alpha = 0
    cluetext.x = -633;
    cluetext.y = 435
    createjs.Tween.get(cluetext).wait(1000)
        .to({ x: 633, alpha: 1, visible: true }, 500)    

   for (i = 1; i <= len; i++) {
        optionArr[i].visible = true;
        optionArr[i].alpha = 0
        optionArr[i].y = 525
           optionArr[i].scaleX= optionArr[i].scaleY=.75
            if (len == 5) {
            optionArr[i].x = 325 + (i * 100)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
       else if (len == 6) {
            optionArr[i].x = 300 + (i * 100)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
        else if (len == 7) {
            optionArr[i].x = 280 + (i * 90)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)

        }
        else if (len == 8) {
            optionArr[i].x = 235 + (i * 90)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
        else if (len == 9) {
            optionArr[i].x = 190 + (i * 90)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
        else {
            optionArr[i].x = 150 + (i * 90)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
    }
    repTimeClearInterval = setTimeout(AddListenerFn, 2000);
}
function AddListenerFn() {
    clearTimeout(repTimeClearInterval)     
    for (i = 1; i <= len; i++) {
        optionArr[i].addEventListener("click", answerSelected);
        optionArr[i].visible = true;
        optionArr[i].alpha = 1;
        optionArr[i].cursor = "pointer";
        optionArr[i].mouseEnabled = true;
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer();
}

function disablechoices() {
    for (i = 1; i <= len; i++) {
        optionArr[i].removeEventListener("click", answerSelected);
        optionArr[i].visible = false;
        optionArr[i].alpha = .5;
    }
    for (i = 1; i <= 5; i++) {
        choiceArr[i].visible = false;
    }
}
///////////////////////////////////////////////////////////========ANSWER VALIDATION========//////////////////////////////////////////////////////////////////



/*  Always "ans" and "uans" must be present for validation. They must not be changed.  */



function answerSelected(e) {

    clk++;
    e.preventDefault();
    uans = e.currentTarget.name;
    tempuans += uans;
    e.currentTarget.mouseEnabled = false;
    e.currentTarget.visible = false
    e.currentTarget.cursor = "default"
    console.log("answer" + uans);
    gameResponseTimerStop();
    if (uans == ansArr[clk - 1]) {
        choiceArr[clk].visible = true;
         choiceArr[clk].alpha=0.5
          choiceArr[clk].y=300
              createjs.Tween.get(choiceArr[clk]).wait(100)
        .to({ y: 283, alpha: 1 }, 500)
        if (clk == 5) {      

            uans = tempuans;
              setTimeout(correct, 500);
        
        }

    } else {
        uans = tempuans;
        getValidation("wrong");
        disablechoices();

    }

}
  function correct() {
    getValidation("correct");
    disablechoices();
}
