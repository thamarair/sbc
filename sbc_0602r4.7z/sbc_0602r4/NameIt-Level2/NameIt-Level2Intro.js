 var  introArrow, introQuestionText,   introfingure, introTitle;
var introChoice1TweenArr = []
var introOptionArr=[]
var TempIntroVal;
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introQuestxtX = -200; introQuestxtY = 0;
var introArrowX = 615, introArrowY = 540;
var introfingureX = 635, introfingureY = 600;
//410,480,550,620,690,760,830,900
var ArrowXArr = [, 740,390,660,925], FingXArr = [,765,425, 680,945]
var ArrowYArr = [, 500, 500, 500,500], FingYArr = [, 580, 580, 580,580]
var introAnsText=[]
var ques=[2,14,12,15,20,19,4,17]
function commongameintro() {

    introTitle = Title.clone()
    container.parent.addChild(introTitle)
    introTitle.visible = true;
    introQuestionText = questionText.clone();
    introArrow = arrow1.clone()
    introfingure = fingure.clone()


 
    container.parent.addChild(introQuestionText)
    introQuestionText.visible = true;
      
    introtxtLabel = new createjs.Text(" ", "44px lato-Bold", "black")
    container.parent.addChild(introtxtLabel)
    introtxtLabel.textAlign = "center";
    introtxtLabel.textBaseline = "middle";
    introtxtLabel.x = 633
    introtxtLabel.y = 392


  for (i = 1; i <=8; i++) {
        introOptionArr[i] = choice1.clone();
        container.parent.addChild(introOptionArr[i])
        introOptionArr[i].scaleX=  introOptionArr[i].scaleY=.75
        introOptionArr[i].visible = false;
        introOptionArr[i].x = 235 + (i * 90)
        introOptionArr[i].y = 600
        introOptionArr[i].gotoAndStop(ques[i-1])
    }

    for (i = 1; i <= 4; i++) {
        introChoice1TweenArr[i] = btn.clone();
        container.parent.addChild(introChoice1TweenArr[i])
        introChoice1TweenArr[i].visible = false;
        introChoice1TweenArr[i].x = 405 + (i * 90);
        introChoice1TweenArr[i].y = 284
        introChoice1TweenArr[i].scaleX = introChoice1TweenArr[i].scaleY = .7
    }
introChoice1TweenArr[1].gotoAndStop(19);
introChoice1TweenArr[2].gotoAndStop(14);
introChoice1TweenArr[3].gotoAndStop(20);
introChoice1TweenArr[4].gotoAndStop(17);



    introQuestionText.alpha = 0;
    introQuestionText.x = -200
    createjs.Tween.get(introQuestionText)
    .to({ x: 0, alpha: 1 }, 1000)
        .call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()

    }
  
    else {
        createjs.Tween.removeAllTweens();
        choiceTween()
    }
}
function choiceTween() {
        TempIntroVal=0;
    var val=250
  for (i = 1; i <= 8; i++) {
  
        introOptionArr[i].visible = true;
          introOptionArr[i].alpha=0
   
      {
    
      if (i == 8) {
        createjs.Tween.get(introOptionArr[i]).wait(val)
        .to({ y: 610, alpha: 1 }, 500).call(handleComplete3_2)
      }
      else{
         createjs.Tween.get(introOptionArr[i]).wait(val)
        .to({ y: 610, alpha: 1 }, 500) 
      }
val=val+150
      }
  }
}


function handleComplete3_2() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        createjs.Tween.removeAllTweens();
        clueTween()
    }
}
function clueTween() {
  
    introtxtLabel.visible = true;
    introtxtLabel.alpha = 0
    introtxtLabel.x = -633;
    introtxtLabel.y=430
    createjs.Tween.get(introtxtLabel).wait(1000)
        .to({text:"A journey across different places" ,x: 633, alpha: 1 ,visible:true}, 500)
        .to({scaleX:1,scaleY:1}, 500)
        .to({scaleX:.9,scaleY:.9}, 500)
        .to({scaleX:1,scaleY:1}, 500)
        .to({scaleX:.9,scaleY:.9}, 500)
        .to({scaleX:1,scaleY:1}, 500)
        .call(handleComplete4_1)

}


function handleComplete4_1() {
    createjs.Tween.removeAllTweens();
    setTimeout(setArrowTween, 500)
}

function setArrowTween() {
    TempIntroVal++;
    if (stopValue == 0) {
        console.log("setArrowTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introfingure.visible = false;
        introArrow.x = ArrowXArr[TempIntroVal];
        introArrow.y = ArrowYArr[TempIntroVal];
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow)
            .to({ y: ArrowYArr[TempIntroVal] + 10 }, 250)
            .to({ y: ArrowYArr[TempIntroVal] }, 250)
            .wait(100)
            .call(this.onComplete1)
    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()
        }
    else {
        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
     
        introfingure.visible = true;
        introfingure.x = FingXArr[TempIntroVal];
        introfingure.y = FingYArr[TempIntroVal];
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        if (TempIntroVal == 5) {
            highlightTweenArr[1] = createjs.Tween.get(introfingure)
                .to({ x: FingXArr[TempIntroVal] }, 250)
                .to({ x: FingXArr[TempIntroVal] - 15 }, 250)        
                .wait(200).call(handleComplete2_2)
        }
        else {
            highlightTweenArr[1] = createjs.Tween.get(introfingure)
                .to({ x: FingXArr[TempIntroVal] }, 250)
                .to({ x: FingXArr[TempIntroVal] - 15 }, 250)               
                .wait(200).call(handleComplete2_2)
        }


    }
}

this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();
    // for (i = 0; i < 2; i++) {
    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }
    // }
    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();    
    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }    
    container.parent.removeChild(introfingure);
    introfingure.visible = false;
    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()
    }
    else {
        setTimeout(setCallDelay, 500)
    }

}

function handleComplete2_2() {
    createjs.Tween.removeAllTweens();   
    answerTween() 
}
function answerTween()
{  
   if (TempIntroVal == 4) 

{
     createjs.Tween.get(introChoice1TweenArr[4])
         .to({ visible:true,alpha: 1 }, 500)
        .call(this.onComplete2)
}
else if (TempIntroVal == 3) 
{
createjs.Tween.get(introChoice1TweenArr[3])
 .to({ visible:true,alpha: 1 }, 500)
 .call(handleComplete4_1)
}

 else if (TempIntroVal == 2) 
 {
createjs.Tween.get(introChoice1TweenArr[2])
.to({visible:true, alpha: 1 }, 500)
 .call(handleComplete4_1)
 }
 else if(TempIntroVal == 1) 
 {
createjs.Tween.get(introChoice1TweenArr[1])
         .to({visible:true, alpha: 1 }, 500)
 .call(handleComplete4_1)
}
}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }
}
function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false

 
    container.parent.removeChild(introQuestionText)
    introQuestionText.visible = false
  
    container.parent.removeChild(introtxtLabel)
    introtxtLabel.visible = false;
 for (i = 1; i <= 8; i++) {
       
        container.parent.removeChild(introOptionArr[i])
        introOptionArr[i].visible=false}
    for (i = 1; i <= 4; i++) {

        container.parent.removeChild(introChoice1TweenArr[i])
        introChoice1TweenArr[i].visible = false;
}
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}