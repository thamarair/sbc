//////////////////////////////////////////////////////===========COMMON GAME VARIABLES==========/////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var j = 1;
var cnt = -1, qscnt = -1, ans, bg, uans, len, cluetext, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, maxCount = 10, choiceCnt = 4, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;

var startBtn, introScrn, container, choice1, choice2, choice3, choice4, question, circleOutline, circle1Outline, boardMc, helpMc, quesMarkMc, questionText, quesHolderMc, resultLoading, preloadMc;

var mc, startMc, ch = 0, n = 0, noMc, yesMc, background1;

var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc;

var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;

var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;

var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q

var isBgSound = true;

var isEffSound = true;

var isOlderBrowser = false;

var isLandOrientation = false;

var url = "";

var nav = "";

var isResp = true;

var respDim = 'both'

var isScale = true

var scaleType = 1;

var lastW, lastH, lastS = 1;

var borderPadding = 10, barHeight = 20;

var loadProgressLabel, progresPrecentage, loaderWidth;

////////////////////////////////////////////////////==========GAME SPECIFIC VARIABLES============/////////////////////////////////////////////////////////////
// var Questio


// //////////////////////////////////////////////////////==========GAME SPECIFIC ARRAYS============/////////////////////////////////////////////////////////////

var answerArr = ["Tour", "Pour", "True", "Crop", "Term",
    "Vote", "Toes", "Live", "Lost", "Slot",
    "Omit", "Stem", "Shoe", "Hint", "Time",
    "Limb", "Mile", "Boil", "Mole", "Tall",
    "Tail", "Nail", "Rail", "Bill", "Ride",
    "Rise", "Code", "Iron", "Cone", "Over",
    "Rose", "Verb", "Ever", "Bees", "Stop",
    "Spot", "Pipe", "Pets", "Post", "Pass",
    "Page", "Gaps", "Peas", "Seas", "Name",
    "Mine", "Main", "Exam", "Mean", "Tear",
    "Rent", "Nice", "Neat", "Near"]
var questionArr = ["COMPUTER", "COMPUTER", "COMPUTER", "COMPUTER", "COMPUTER",
    "TELEVISION", "TELEVISION", "TELEVISION", "TELEVISION", "TELEVISION",
    "SOMETHING", "SOMETHING", "SOMETHING", "SOMETHING", "SOMETHING",
    "MOBILE", "MOBILE", "MOBILE", "MOBILE",
    "BRILLIANT", "BRILLIANT", "BRILLIANT", "BRILLIANT", "BRILLIANT",
    "CONSIDER", "CONSIDER", "CONSIDER", "CONSIDER", "CONSIDER",
    "OBSERVE", "OBSERVE", "OBSERVE", "OBSERVE", "OBSERVE",
    "OPPOSITE", "OPPOSITE", "OPPOSITE", "OPPOSITE", "OPPOSITE",
    "PASSAGE", "PASSAGE", "PASSAGE", "PASSAGE", "PASSAGE",
    "EXAMINE", "EXAMINE", "EXAMINE", "EXAMINE", "EXAMINE",
    "CERTAIN", "CERTAIN", "CERTAIN", "CERTAIN", "CERTAIN"]
var clueArrEnglish = ["A journey across different places", "Move liquid out of a container", "Correct", "Cultured plant", "A limited period of time",
    "Making a political choice", "Digits on feet", "Remain alive", "Unable to find ones way", "Specific time frame",
    "Exclude", "Central part of a plant", "Worn on the feet", "Clue", "Duration between events",
    "An arm or leg", "A measure of distance", "When liquid turns to vapour through heating", "A small buffowing animal",
    "More than average height", "Hind most part of an animal", "Small metal spike", "A long metal bar", "Statement of money owed",
    "A journey on or in something", "Get up", "A set of rules", "Strong magnetic metal", "Part of an ice cream",
    "Six balls in cricket", "Type of flower", "Word describing an action", "At any time", "Flying insect that produces honey",
    "Come to an end", "See, notice or recognize", "A tube", "Domestic animals", "Announce or publish",
    "Go past or across", "Part of a notebook", "Small spaces", "Small spherical green bodies", "Vast water bodies",
    "How a person is known", "Where precious minerals are extracted", "Most important", "A specified test", "Average",
    "Pull apart", "Pay for the use of", "Kind", "Tidy", "Close by"]
    var clueArrTamil = ["வெவ்வேறு இடங்களுக்கு செல்லும் பயணம் ", "பாத்திரத்திலிருந்து திரவம் கசிவது ", "சரி ", "முறையாக வளர்க்கப்பட்ட செடி ", "வரையறுக்கப்பட்ட காலம்",
    "அடிப்படை உரிமை", "கால் விரல்களின்  எண்ணிக்கை", "உயிரோடு இருப்பது", "வழி கண்டுபிடிக்க முடியவில்லை", "குறிப்பிட்ட கால அளவு",
    "விலக்குதல் ", "ஒரு செடியின் முக்கிய பகுதி", "பாதத்தில் அணியப்படுவது", "துப்பு ", "காலத்தை அளக்கும் சொல் ",
    "ஒரு கை அல்லது காலைக் குறிக்கும் சொல்", "இரு இடங்களுக்குள் இருக்கும் தூரத்தின் அளவீடு ", "திரவ நிலை நீராவியாக மாறுதல் ", "ஒரு சிறிய வளைவாழ் விலங்கு ",
    "சராசரி உயரத்தை விட கூடுதல் ", "விலங்குகளின் உடம்பின் கடைசி உறுப்பு", "சிறிய உலோக முள்", "நீண்ட உலோகக் கட்டைகள்", "செலுத்த வேண்டிய பணம் பற்றிய  அறிக்கை",
    "எதன் மீதாவது பயணம் செய்வது ", "எழுந்திரு ", "விதிகளின் தொகுப்பு", "வலுவான காந்தசக்தியுள்ள உலோகம் ", "ஐஸ்கிரீமின் ஒரு பகுதி ",
    "கிரிக்கெட் பந்தயத்தில் ஆறு பந்துகள் ", "ஒரு வகை பூ ", "ஒரு செயலைக் குறிக்கும் சொல் ", "எந்த நேரத்திலும் ", "தேன் தரும் பறக்கும் பூச்சி ",
    "முடிவுக்கு வருவது", "பார்த்தல் அல்லது அடையாளம் கண்டுகொள்ளுதல்", "ஒரு குழாய் ", "வீட்டு விலங்குகள்", "அறிவிப்பது அல்லது வெளியிடுவது",
    "கடந்து செல்வது ", "ஒரு நோட்டுப்புத்தகத்தின் பகுதி", "சிறிய இடைவெளிகள்", "சிறிய கோள் வடிவான பச்சை நிற பொருட்கள் ", "மிகப்பெரிய நீர்நிலைகள் ",
    "ஒரு மனிதனின் அடையாளம் ", "விலைமதிப்பில்லா தாதுப்பொருட்கள் இருக்கும் இடம் ", "மிக முக்கியமானது ", "குறிப்பிட்ட ஒரு தேர்வு ", "சராசரி ",
    "தனியாகப் பிரித்தல்", "உபயோகத்திற்காக செலுத்தும் பணம் ", "அன்பான ", "சுத்தமான ", "நெருக்கத்தில் "]

   
    var clueArrArabic = ["رحلةٌ بين أماكن مختلفة", "أخرج السائل من الوعاء", "صحيح", "النبتة المستنبتة", "فترة محدودة من الزمن",
    "اتخاذ خيار سياسي", "أرقام على الأقدام", "البقاء على قيد الحياة", "غير قادر على إيجاد الطريق", "الإطار الزمني المحدد",
    "استثنِ", "الجزء المركزي للنبات", "تلبس في الأقدام", "دليل", "المدة بين الأحداث",
    "ذراع أم ساق", "قياس المسافة", "عندما يتحول السائل إلى بخار عبر التسخين", "حيوان جحور صغير",
    "أطول من الطول المتوسط", "الجزء الأخير الخلفي من الحيوان", "مسمار معدني صغير", "قضيب معدني طويل", "بيان الأموال المستحقة",
    "رحلة على أو في شيء ما", "استيقظ", "مجموعة من القواعد", "معدن مغناطيسي قوي", "قطعة من آيس كريم",
    "ست كرات في لعبة الكريكيت", "نوع الزهرة", "كلمة تصف الحركة", "في أي وقت", "الحشرة الطائرة التي تنتج العسل",
    "وصل إلى نهاية", "شاهد، أو لاحظ أو تعرف على", "أنبوب", "الحيوانات الأليفة", "أَعلِن أو أُنشُر",
    "جزء من كرّاسة", "جزء من أنيق", "مساحات صغيرة", "أشكال كروية خضراء صغيرة", "المسطحات المائية الواسعة",
    "كيف يُعرف الشخص", "من أين يتم استخراج المعادن الثمينة", "الأهم", "اختبار محدد", "معدل",
    "يمزق", "دفع لاستخدام", "طيب", "مرتّب", "قريب من"];


    
var alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
var tempuans = "";
var qno = [];
var choiceArr = []
var optionArr = []
var ansArr = []
var tweenMcArr = []
/////////////////////////////////////////////////////////=========BROWSER SUPPORT============////////////////////////////////////////////////////////////////

//register key functions

window.onload = function (e) {

    checkBrowserSupport();

}

//////////////////////////////////////////////////////////=========INITIALIZATION=============///////////////////////////////////////////////////////////////

function init() {

    console.log("innt")



    canvas = document.getElementById("gameCanvas");

    stage = new createjs.Stage(canvas);

    container = new createjs.Container();

    stage.addChild(container)

    createjs.Ticker.addEventListener("tick", stage);

    callLoader();

    createLoader();

    createCanvasResize()



    stage.update();

    stage.enableMouseOver(40);



    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////



    /*Always specify the following terms as given in manifest array. 

         1. choice image name as "ChoiceImages1.png"

         2. question text image name as "questiontext.png"

     */

    assetsPath = "assets/";
    gameAssetsPath = "NameIt-Level1/";
    soundpath = "LI/"


    var success = createManifest();

    if (success == 1) {

        manifest.push(
            { id: "choice1", src: gameAssetsPath + "choiceImages1.png" },
            { id: "btn", src: gameAssetsPath + "btnImages1.png" },
           
            { id: "questionText", src: questionTextPath + "NameIt-Level1-QT.png" }
       
        )

        preloadAllAssets()
        stage.update();
    }
}
function doneLoading1(event) {

    var event = assets[i];
    var id = event.item.id;
    

    if (id == "choice1") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 100, "count": 0, "regY": 50, "width": 100 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });

        choice1 = new createjs.Sprite(spriteSheet2);
        choice1.visible = false;
        container.parent.addChild(choice1);
        choice1.x = 400; choice1.y = 400;
    };

    if (id == "btn") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("btn")],
            "frames": { "regX": 50, "height": 119, "count": 0, "regY": 50, "width": 119 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        btn = new createjs.Sprite(spriteSheet2);
        btn.visible = false;
        container.parent.addChild(btn);
    };

    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }

}



function tick(e) {

    stage.update();

}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////

function handleClick(e) {
    qno = between(0, 53);
    console.log("qno= " + qno)
    qno.sort(randomSort);
    CreateGameStart()

    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }

}

////////////////////////////////////////////////////////////=========GAME ELEMENTS CREATION===========//////////////////////////////////////////////////////


function CreateGameElements() {

    interval = setInterval(countTime, 1000);


    cluetext = new createjs.Text("", "44px lato-Bold", "black")
    container.parent.addChild(cluetext)
    cluetext.textAlign = "center";
    cluetext.textBaseline = "middle";
    cluetext.x = 633
    cluetext.y = 392

    for (i = 1; i <= maxCount; i++) {
        optionArr[i] = choice1.clone();
        container.parent.addChild(optionArr[i])
        optionArr[i].visible = false;
        optionArr[i].x = 100 + (i * 60);
        optionArr[i].y = 555
         optionArr[i].scaleX= optionArr[i].scaleY=.75
      
    }

    for (i = 1; i <= 4; i++) {
        choiceArr[i] = btn.clone();
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false;
        choiceArr[i].x = 420 + (i * 90);
        choiceArr[i].y = 240
        choiceArr[i].scaleX = choiceArr[i].scaleY = .7
    }
    questionText.visible = false;
    questionText.x = 0
    questionText.y = 0
    container.parent.addChild(questionText);

}

/////////////////////////////////////////////////////////=======HELP POP-UP CONTROL=======//////////////////////////////////////////////////////////////

function helpDisable() {
    for (i = 1; i <= len; i++) {
        optionArr[i].mouseEnabled = false;
    }
}



function helpEnable() {
    for (i = 1; i <= len; i++) {
        optionArr[i].mouseEnabled = true;
    }
}

//////////////////////////////////////////////////////////===========GAME LOGIC============///////////////////////////////////////////////////////////////

function pickques() {

    //======================================================RESET VARIABLES=====================================================================    
    pauseTimer()
    tx = 0;
    clk = 0;
    cnt++; qscnt++;
    quesCnt++;
    ansArr = [];
    panelVisibleFn()
    //===========================================================LOGIC AREA============================================================================\
    tempuans = "";
    console.log(questionArr)
   
    cluetext.visible = false;
    question = questionArr[qno[cnt]];
    len = question.length;
    console.log("length " + len)

    for (i = 0; i < len; i++) {
        var char = question.charAt(i);
        var index = alphabet.indexOf(char)
        optionArr[i + 1].gotoAndStop(index)
        optionArr[i + 1].visible = false;
        optionArr[i + 1].name = char
    }
    ans = answerArr[qno[cnt]];
    console.log("ans" + ans)
    for (i = 0; i < 4; i++) {
        ansArr.push(ans.charAt(i).toString().toUpperCase());
        var index = alphabet.indexOf(ansArr[i])
        choiceArr[i + 1].gotoAndStop(index)
        choiceArr[i + 1].visible = false;
    }

    //===========================================================End LOGIC AREA============================================================================\


    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();

}

//===================================================================================================================================================================//
function createTween() {
    questionText.visible = true;
    questionText.alpha = 0
    questionText.scaleX = .99
    createjs.Tween.get(questionText).wait(100).to({ alpha: 1 }, 200)


    cluetext.visible = true;
    cluetext.alpha = 0
    cluetext.x = -633;
    cluetext.y = 435
    if (lang == "EnglishQuestionText/") {      
        cluetext.text = clueArrEnglish[qno[cnt]];
        cluetext.font="bold 44px lato-Bold"
        createjs.Tween.get(cluetext).wait(1000)
        .to({ x: 633,alpha: 1, visible: true }, 500)
    }
    else if (lang == "TamilQuestionText/") {
        
        cluetext.text = clueArrTamil[qno[cnt]];
        cluetext.font="bold 25px lato-Bold";
       createjs.Tween.get(cluetext).wait(1000)
        .to({ x: 633 ,alpha: 1, visible: true }, 500)
    }
    else if (lang == "ArabicQuestionText/") {

        cluetext.text = clueArrArabic[qno[cnt]];
        cluetext.font = "bold 37px lato-Bold";
        createjs.Tween.get(cluetext).wait(1000)
            .to({ x: 633, alpha: 1, visible: true }, 500)
    }
    else {      
        cluetext.text = clueArrEnglish[qno[cnt]];
        cluetext.font="bold 44px lato-Bold"
        createjs.Tween.get(cluetext).wait(1000)
        .to({ x: 633,alpha: 1, visible: true }, 500)
    }
    for (i = 1; i <= len; i++) {
        optionArr[i].visible = true;
        optionArr[i].alpha = 0
        optionArr[i].y = 525
           optionArr[i].scaleX= optionArr[i].scaleY=.75
        if (len == 6) {
            optionArr[i].x = 300 + (i * 100)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
        else if (len == 7) {
            optionArr[i].x = 270 + (i * 90)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)

        }
        else if (len == 8) {
            optionArr[i].x = 235 + (i * 90)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
        else if (len == 9) {
            optionArr[i].x = 200 + (i * 90)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
        else {
            optionArr[i].x = 180 + (i * 90)
            createjs.Tween.get(optionArr[i]).wait(1000)
                .to({ y: 630, alpha: 1 }, 500)
        }
    }



    repTimeClearInterval = setTimeout(AddListenerFn, 2000)


}
function AddListenerFn() {

    clearTimeout(repTimeClearInterval)  
    
    for (i = 1; i <= len; i++) {
        optionArr[i].addEventListener("click", answerSelected);
        optionArr[i].visible = true;
        optionArr[i].alpha = 1;
        optionArr[i].cursor = "pointer";
        optionArr[i].mouseEnabled = true;
    }

    rst = 0;
    gameResponseTimerStart();
    restartTimer()

}

function disablechoices() {
    for (i = 1; i <= len; i++) {
        optionArr[i].removeEventListener("click", answerSelected);
        optionArr[i].visible = false;
        optionArr[i].alpha = .5;

    }
    for (i = 1; i <= 4; i++) {

        choiceArr[i].visible = false;

    }


}

///////////////////////////////////////////////////////////========ANSWER VALIDATION========//////////////////////////////////////////////////////////////////



/*  Always "ans" and "uans" must be present for validation. They must not be changed.  */



function answerSelected(e) {

    clk++;
    e.preventDefault();
    uans = e.currentTarget.name;
    tempuans += uans;
    e.currentTarget.mouseEnabled = false;
    e.currentTarget.visible = false
    e.currentTarget.cursor = "default"
    console.log("answer" + uans);
    gameResponseTimerStop();
    if (uans == ansArr[clk - 1]) {
        choiceArr[clk].visible = true;
        choiceArr[clk].alpha = 0.5
        choiceArr[clk].y = 280
        createjs.Tween.get(choiceArr[clk]).wait(100)
            .to({ y: 293, alpha: 1 }, 500)
        if (clk == 4) {


            uans = tempuans;
            setTimeout(correct,500)
           
        }

    } else {
        uans = tempuans;
        getValidation("wrong");
        disablechoices();

    }

}
function correct() {
    getValidation("correct");
    disablechoices();
}