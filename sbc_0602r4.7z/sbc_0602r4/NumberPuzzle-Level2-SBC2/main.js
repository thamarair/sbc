

//////////////////////////////////////////////////////===========COMMON GAME VARIABLES==========/////////////////////////////////////////////////////////////



var messageField;	//Message display field
var assets = [];
var assetsPath, gameAssetsPath, soundpath, bg;
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 6, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, boardMc, helpMc, resultLoading, preloadMc;
var startMc, questionInterval = 0, backGround1;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q
var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;
////////////////////////////////////////////////////==========GAME SPECIFIC VARIABLES============/////////////////////////////////////////////////////////////
var choice1, choice2, choice3, choice4, question, questionText, chHolderMc,  answer1, answer2, answer3, answer4;
var ts;
//////////////////////////////////////////////////////==========GAME SPECIFIC ARRAYS============/////////////////////////////////////////////////////////////
var qno = [];
var qno1 = [];
var chpos = []
var tweenMcArr = []
var labelArr = []
choiceArr
var wordArr = []
var choiceArr = [1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2];
var mcArr = [];
var questionArr = []
var total;
var picques = []
var ChoiceArr0 = ["643","910","735","625","545","739","809","969","562","931","982","699","524","484","973","157","988","557","533","936",
"794","848","976","714","540","949","714","672","929","935","382","841","924","883","871","940","472","838","790","507","587","535","958","566","862","638","986","865","805","932"]
var answers = []
var ChoiceArr1 = ["473","427","188","183","441","708","538","169","479","449","317","511","324","300","449","145","913","311","411","114","529","651","845","466","316",
"681","450","500","799","678","171","256","376","615","214","111","360","656","342","258","308","371","797","457","446","379","194","191","505","573"]
var category = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2]
var choiceArr = []
//register key functions
/////////////////////////////////////////////////////////=========BROWSER SUPPORT============////////////////////////////////////////////////////////////////
window.onload = function (e) {
    checkBrowserSupport();
}
//////////////////////////////////////////////////////////=========INITIALIZATION=============///////////////////////////////////////////////////////////////
function init() {
    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);
    callLoader();
    createLoader();
    createCanvasResize()
    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////
    /*Always specify the following terms as given in manifest array. 

         1. choice image name as "ChoiceImages1.png"

         2. question text image name as "questiontext.png"

     */
    assetsPath = "assets/";
    gameAssetsPath = "NumberPuzzle-Level2-SBC2/";
    soundpath = "VP/"
    // xmlName = questionTextPath + "Xml/game_data_NumberPuzzle.xml";
    var success = createManifest();
    if (success == 1) {
        manifest.push(
      
            { id: "btnImages", src: gameAssetsPath + "btnImages.png" },
            { id: "question",  src: gameAssetsPath + "question.png" },
            { id: "introimage1", src: questionTextPath + "Hint/NumberPuzzle-Level2-Hint1.png" },
            { id: "introimage2", src: questionTextPath + "Hint/NumberPuzzle-Level2-Hint2.png" },
            { id: "introimage3", src: questionTextPath + "Hint/NumberPuzzle-Level2-Hint3.png" },
            { id: "introimage4", src: questionTextPath + "Hint/NumberPuzzle-Level2-Hint4.png" },
            { id: "introimage5", src: questionTextPath + "Hint/NumberPuzzle-Level2-Hint5.png" },
            { id: "introimage6", src: questionTextPath + "Hint/NumberPuzzle-Level2-Hint6.png" },
            { id: "introimage7", src: questionTextPath + "Hint/NumberPuzzle-Level2-Hint7.png" },
            { id: "questionText", src: questionTextPath + "NumberPuzzle-Level2-SBC2-QT.png" }
        )
        preloadAllAssets()
        stage.update();
    }
}
////////////////////////////////////////////////////////////==========PRELOADER===========/////////////////////////////////////////////////////////////////

function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;
    if (id == "question") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("question")],
            "frames": { "regX": 50, "height": 108, "count": 0, "regY": 50, "width": 107 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        question = new createjs.Sprite(spriteSheet2);
        question.visible = false;
        container.parent.addChild(question);
    };
    if (id == "btnImages") {
        var spriteSheet3 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("btnImages")],
            "frames": { "regX": 50, "height": 100, "count": 0, "regY": 50, "width": 106 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):
        });
        choice1 = new createjs.Sprite(spriteSheet3);
        choice1.visible = false;
        container.parent.addChild(choice1);
    };
    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false;
    }
  

    if (id == "introimage1") {
        introimage1 = new createjs.Bitmap(preload.getResult('introimage1'));
        container.parent.addChild(introimage1);
        introimage1.visible = false;

    }

    if (id == "introimage2") {
        introimage2 = new createjs.Bitmap(preload.getResult('introimage2'));
        container.parent.addChild(introimage2);
        introimage2.visible = false;
    }

    if (id == "introimage3") {
        introimage3 = new createjs.Bitmap(preload.getResult('introimage3'));
        container.parent.addChild(introimage3);
        introimage3.visible = false;
    }

    if (id == "introimage4") {
        introimage4 = new createjs.Bitmap(preload.getResult('introimage4'));
        container.parent.addChild(introimage4);
        introimage4.visible = false;
    }

    if (id == "introimage5") {
        introimage5 = new createjs.Bitmap(preload.getResult('introimage5'));
        container.parent.addChild(introimage5);
        introimage5.visible = false;
    }

    if (id == "introimage6") {
        introimage6 = new createjs.Bitmap(preload.getResult('introimage6'));
        container.parent.addChild(introimage6);
        introimage6.visible = false;
    }

    if (id == "introimage7") {
        introimage7 = new createjs.Bitmap(preload.getResult('introimage7'));
        container.parent.addChild(introimage7);
        introimage7.visible = false;
    }

}
function tick(e) {
    stage.update();
}
/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////

function handleClick(e) {
    qno = between(0, 24)

    qno.splice(qno.indexOf(0), 1)
    qno.push(0)
    CreateGameStart()

    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
}

////////////////////////////////////////////////////////////=========GAME ELEMENTS CREATION===========//////////////////////////////////////////////////////

function CreateGameElements() {

    interval = setInterval(countTime, 1000);
    // Add for db code
    container.parent.addChild(questionText);
    questionText.visible = false;
  
    //======================================================================//
    var px = 455;
    var py = 240;
    var xpadding = 178;
    var ypadding = 130;
    var j = 0;
    for (i = 1; i <= choiceCnt; i++) {
        j++;
        this["question" + i] = question.clone()
        this["question" + i].gotoAndStop(i);
        this["question" + i].visible = false;
        container.parent.addChild(this["question" + i])
        this["question" + i].x = px + ((j - 1) * xpadding);
        this["question" + i].y = py;
        if (i == 3) {
            j = 0;
            py = py + ypadding;
        }
        this["question" + i].scaleX = this["question" + i].scaleY = 1.2;
    }
    for (i = 1; i <= 4; i++) {
        this["answer" + i] = question.clone()
        this["answer" + i].visible = false;
        this["answer" + i].x = 633 + ((i - 1) * 180);
        this["answer" + i].y = 525;
        container.parent.addChild(this["answer" + i])
    }
    btnx = [285, 635, 985]
    for (i = 1; i <= 3; i++) {
        this["choice" + i] = choice1.clone()
        this["choice" + i].visible = false;
        this["choice" + i].x = btnx[i - 1];
        this["choice" + i].y = 660;
        if (i == 2) {
            this["choice" + i].y = 665;
        }
        console.log(this["choice" + i].x)
        this["choice" + i].scaleX = this["choice" + i].scaleY = .9
        container.parent.addChild(this["choice" + i])

    }
    if (isQuestionAllVariations) {
        choiceArr = [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2];
    } else {
        choiceArr = [1, 2, 1, 2, 1, 2, 1, 2, 1, 2]
    }
 choiceArr.sort(randomSort);
    console.log("choiceArr" + choiceArr)
}

/////////////////////////////////////////////////////////=======HELP POP-UP CONTROL=======//////////////////////////////////////////////////////////////

function helpDisable() {
    for (i = 1; i <= 3; i++) {
        this["choice" + i].mouseEnabled = false;
    }
}

function helpEnable() {
    for (i = 1; i <= 3; i++) {
        this["choice" + i].mouseEnabled = true;
    }
}

//////////////////////////////////////////////////////////===========GAME LOGIC============///////////////////////////////////////////////////////////////

function pickques() {
    pauseTimer()
    //======================================================RESET VARIABLES=====================================================================    
    tx = 0;
    cnt++;
    qscnt++;
    quesCnt++;
    chpos = [];
    answers = [];
    panelVisibleFn()
    //===========================================================LOGIC AREA============================================================================


    for (i = 1; i <= 4; i++) {
        this["answer" + i].visible = false;
    }
 
    if (choiceArr[cnt] == 1) {
        var fArr = (ChoiceArr0[qno[cnt]]).split("");
        var sArr = (ChoiceArr1[qno[cnt]]).split("");
        var ans1 = ChoiceArr0[qno[cnt]];
        var ans2 = ChoiceArr1[qno[cnt]];
        total = parseInt(ans1) + parseInt(ans2);
        ts = total.toString().length;
    }
    else {
        console.log(qno[cnt])
        console.log(qno[cnt] + 25)
        var fArr = (ChoiceArr0[qno[cnt] + 25]).split("");
        var sArr = (ChoiceArr1[qno[cnt] + 25]).split("");
        var ans1 = ChoiceArr0[qno[cnt] + 25];
        var ans2 = ChoiceArr1[qno[cnt] + 25];
        total = parseInt(ans1) - parseInt(ans2);
        ts = total.toString().length;

    }

    for (i = 1; i <= 3; i++) {
        this["question" + i].gotoAndStop(parseInt(fArr[i - 1]))
    }
    for (i = 4; i <= 6; i++) {
        this["question" + i].gotoAndStop(parseInt(sArr[i - 4]))
    }


    if (ts == 3) {
        for (i = 1; i <= 3; i++) {
            this["answer" + i].x = 455 + ((i - 1) * 180);
            this["answer" + (3 - (i - 1))].visible = true;
            this["answer" + (3 - (i - 1))].alpha = 0;
            this["answer" + (3 - (i - 1))].gotoAndStop(total % 10);
            this["answer" + (3 - (i - 1))].name = total % 10;
            total = Math.floor(total / 10);
            this["answer" + (3 - (i - 1))].y = -525
            this["answer" + i].scaleX = this["answer" + i].scaleY = 1
        }
    }
    else if (ts == 4) {
        console.log("total2====" + ts)
        for (i = 1; i <= 4; i++) {
            //   this["answer" + i].x = 433 + ((i - 1) * 125);
            this["answer" + i].x = 300 + ((i - 1) * 170);
            this["answer" + (4 - (i - 1))].visible = true;
            this["answer" + (4 - (i - 1))].alpha = 0;
            this["answer" + (4 - (i - 1))].gotoAndStop(total % 10);
            this["answer" + (4 - (i - 1))].name = total % 10;
            this["answer" + (4 - (i - 1))].y = -525
            total = Math.floor(total / 10);
            this["answer" + i].scaleX = this["answer" + i].scaleY = .9
        }
        
           this["answer" + 1].x = 300 
           this["answer" + 2].x = 455 
            this["answer" + 3].x = 637
             this["answer" + 4].x = 812 
        
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////

    picques = []
    picques = between(1, ts);

    this["answer" + picques[1]].gotoAndStop(10);
    ans = this["answer" + picques[1]].name;
    var ansChArr = between(0, 9);
    var indexs = ansChArr.indexOf(ans);
    ansChArr.splice(indexs, 1);

    answers.push(ans, ansChArr[0], ansChArr[1]);

    answers.sort(randomSort);


    //=========================================================================================================================================================
    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}

function createTween() {
    questionText.visible = true;
    questionText.alpha = 0;
    questionText.x = -290
    questionText.y = 0
    createjs.Tween.get(questionText).wait(100)
        .to({ x: 0, alpha: 1 }, 400, createjs.Ease.bounceIn);




    for (i = 1; i <= choiceCnt; i++) {
        this["question" + i].visible = true;
        this["question" + i].alpha = 0
        this["question" + i].scaleX = this["question" + i].scaleY = 1.2;
        if (i == choiceCnt) {
            createjs.Tween.get(this["question" + i]).wait(1000)
                .to({ visible: true, alpha: 1 }, 500, createjs.Ease.bounceIn)
        }
        else {
            createjs.Tween.get(this["question" + i]).wait(1000)
                .to({ visible: true, alpha: 1 }, 500, createjs.Ease.bounceIn)
        }
    }
    repTimeClearInterval = setTimeout(createTween1, 1500)
}
function createTween1() {
    clearTimeout(repTimeClearInterval)
    var val = 50
    //////////////////////////////////////////////////////////////////////////////////////

    if (ts == 3) {
        console.log("total1====" + ts)
        for (i = 1; i <= 3; i++) {

            if (i == 3) {
                createjs.Tween.get(this["answer" + (3 - (i - 1))]).wait(val)
                    .to({ visible: true, y: 470, alpha: 1, scaleX: 1, scaleY: 1 }, 500, createjs.Ease.bounceIn)
            }
            else {
                createjs.Tween.get(this["answer" + (3 - (i - 1))]).wait(val)
                    .to({ visible: true, y: 470, alpha: 1, scaleX: 1, scaleY: 1 }, 500, createjs.Ease.bounceIn)
            }
            val = val + 50
        }
    }
    else if (ts == 4) {
        console.log("total2====" + ts)
        for (i = 1; i <= 4; i++) {

            if (i == 4) {
                createjs.Tween.get(this["answer" + (4 - (i - 1))]).wait(val)
                    .to({ visible: true, y: 470, alpha: 1, scaleX: 1, scaleY: 1 }, 500, createjs.Ease.bounceIn)
            }
            else {
                createjs.Tween.get(this["answer" + (4 - (i - 1))]).wait(val)
                    .to({ visible: true, y: 470, alpha: 1, scaleX: 1, scaleY: 1 }, 500, createjs.Ease.bounceIn)
            }
            val = val + 50
        }
    }

    for (i = 1; i <= 3; i++) {
        this["choice" + i].gotoAndStop(answers[i - 1]);
        this["choice" + i].name = answers[i - 1]
    }
    //////////////////////////////////////////////////////////////////////////////////////
    var changex = [-285, -635, -985]
    var val1 = 1000
    for (i = 1; i <= 3; i++) {
        this["choice" + i].visible = true;
        this["choice" + i].x = changex[i - 1];
        this["choice" + i].scaleX = this["choice" + i].scaleY = 1
        if (i == 3) {
            createjs.Tween.get(this["choice" + i]).wait(val1)
                .to({ visible: true, rotation: 270, x: btnx[i - 1], alpha: 1 }, 250)
                .to({ visible: true, rotation: 360, x: btnx[i - 1], alpha: 1 }, 250)
        }
        else {
            createjs.Tween.get(this["choice" + i]).wait(val1)
                .to({ visible: true, rotation: 270, x: btnx[i - 1], alpha: 1 }, 250)
                .to({ visible: true, rotation: 360, x: btnx[i - 1], alpha: 1 }, 250)
        }
        val1 = val1 + 50;
    }
    repTimeClearInterval1 = setTimeout(AddListenerFn, 1500)
}
/////////////////////////////////////////////////////////========CHOICES ENABLE/DISABLE=======////////////////////////////////////////////////////////////
function AddListenerFn() {
    clearTimeout(repTimeClearInterval1)
    for (i = 1; i <= 3; i++) {
        this["choice" + i].addEventListener("click", answerSelected);
        this["choice" + i].alpha = 1;
        this["choice" + i].visible = true;
        this["choice" + i].cursor = "pointer";
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}

function disablechoices() {
    for (i = 1; i <= 3; i++) {
        this["choice" + i].removeEventListener("click", answerSelected);
        this["choice" + i].visible = false;
        this["choice" + i].cursor = "default";
    }
    questionText.visible = false;

    for (i = 1; i <= choiceCnt; i++) {
        this["question" + i].visible = false;
    }
    for (i = 1; i <= 4; i++) {
        this["answer" + i].visible = false;
    }
    for (i = 1; i <= 3; i++) {
        this["choice" + i].visible = false;
    }
    stage.update();
}
///////////////////////////////////////////////////////////========ANSWER VALIDATION========//////////////////////////////////////////////////////////////////

/*  Always "ans" and "uans" must be present for validation. They must not be changed.  */

function answerSelected(e) {
    e.currentTarget.removeEventListener("click", answerSelected);
    e.preventDefault();
    uans = e.currentTarget.name;
    gameResponseTimerStop();
    if (ans == uans) {
        console.log("get"+total);
         this["answer" + picques[1]].visible=true;
         this["answer" + picques[1]].gotoAndStop(uans);
          for (i = 1; i <= 3; i++) {
        this["choice" + i].removeEventListener("click", answerSelected);
         
    }
        setTimeout(correct,500)
    } else {
        getValidation("wrong");
        disablechoices();
    }
   
}
function correct()
{
    getValidation("correct");
 disablechoices();

}
