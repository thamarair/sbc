var  introArrow, introQuestionText, introfingure, introTitle;
var introChoice1TweenArr = []
var introHintImage=[];
var introQuesArr = [];
var introQuesArr1 = [];
var introAnswerArr = [];
var TempIntroVal;
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introQuestxtX = -200; introQuestxtY = 0;
var introArrowX = 615, introArrowY = 540;
var introfingureX = 635, introfingureY = 620;
var   introbtnx = [275, 635, 1000]
var   introbtnx1 = [-285, -635, -985]
function commongameintro() {


    introTitle = Title.clone()
    container.parent.addChild(introTitle)
    introTitle.visible = true;
    introQuestionText = questionText.clone();
    introArrow = arrow1.clone()
    introfingure = fingure.clone()
   

    container.parent.addChild(introQuestionText)
    introQuestionText.visible = true;


    for (i = 1; i <= 3; i++) {

        introQuesArr[i] = question.clone()
        introQuesArr[i].visible = false;
        container.parent.addChild(introQuesArr[i])
        introQuesArr[i].x = 450 + ((i - 1) * 178);
        introQuesArr[i].y = 230;
        introQuesArr[i].scaleX = introQuesArr[i].scaleY = 1.15;
    }
    introQuesArr[1].gotoAndStop(7);
    introQuesArr[2].gotoAndStop(2);
    introQuesArr[3].gotoAndStop(5);


    for (i = 1; i <= 3; i++) {

        introQuesArr1[i] = question.clone()
        introQuesArr1[i].visible = false;
        container.parent.addChild(introQuesArr1[i])
        introQuesArr1[i].x = 450 + ((i - 1) * 188);
        introQuesArr1[i].y = 370;
        introQuesArr1[i].scaleX = introQuesArr1[i].scaleY = 1.15;
    }
    introQuesArr1[1].gotoAndStop(5);
    introQuesArr1[2].gotoAndStop(4);
    introQuesArr1[3].gotoAndStop(6);

    for (i = 1; i <= 4; i++) {
        introAnswerArr[i] = question.clone()
        introAnswerArr[i].visible = false;
        introAnswerArr[i].x = 278+ ((i - 1) * 178);
        introAnswerArr[i].scaleX=introAnswerArr[i].scaleY=1
        introAnswerArr[i].y = 530;
        container.parent.addChild(introAnswerArr[i])
    }
         introAnswerArr[1].x = 300 
           introAnswerArr[2].x = 453 
           introAnswerArr[3].x = 640
            introAnswerArr[4].x = 828 

    introAnswerArr[1].gotoAndStop(1);
    introAnswerArr[2].gotoAndStop(10);
    introAnswerArr[3].gotoAndStop(7);
    introAnswerArr[4].gotoAndStop(1);


    for (i = 1; i <= 3; i++) {
      introChoice1TweenArr[i] = choice1.clone()
       introChoice1TweenArr[i].visible = false;
       introChoice1TweenArr[i].gotoAndStop(i)
          introChoice1TweenArr[i].x = introbtnx[i - 1];
           introChoice1TweenArr[i].y = 660;
        if (i == 2) {
                introChoice1TweenArr[i].y = 670;
        }
        console.log(introChoice1TweenArr[i].x)
        introChoice1TweenArr[i].scaleX = introChoice1TweenArr[i].scaleY = .9;
        container.parent.addChild( introChoice1TweenArr[i])
    }


for (i = 1; i <=7; i++) {
        introHintImage[i] =  this["introimage" + i].clone();
        container.parent.addChild(introHintImage[i]);
        introHintImage[i].visible = false;
        introHintImage[i].scalex = introHintImage[i].scaleY = 1      
        introHintImage[i].x = 0;
        introHintImage[i].y = 0;     
    }


    introQuestionText.alpha = 0;
    introQuestionText.visible = true
     introQuestionText.x=-200
    createjs.Tween.get(introQuestionText).to({x:0, alpha: 1 }, 1000)
    .call(handleComplete1_1);
}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
     if (stopValue == 0) {
        removeGameIntro()

    }
    else {

    questionTween()
    }
}

function questionTween() {
var val=250
    for (i = 1; i <= 3; i++) {       
        introQuesArr[i].visible = true;
        introQuesArr[i].alpha=0.5  
             introQuesArr[i].x=(-430) + ((i - 1) * 178) 
             if(i==3) 
             {
               createjs.Tween.get(introQuesArr[i]).wait(val)
      .to({ x:  450 + ((i - 1) * 188) ,alpha:1}, 500).call(handleComplete3_1)
             }
             else
             {
                         createjs.Tween.get(introQuesArr[i]).wait(val)
      .to({ x:  450 + ((i - 1) * 188) ,alpha:1}, 500)
             }
             val=val+50
    }
}

function handleComplete3_1() {
 if (stopValue == 0) {
        removeGameIntro()

    }
    else {
    createjs.Tween.removeAllTweens();
    question1Tween()
    }
}
function  question1Tween()

{    
    var val=250
    for (i = 1; i <= 3; i++) {
        introQuesArr1[i].visible = true;
        introQuesArr1[i].alpha=0.5
        introQuesArr1[i].x=(-430) + ((i - 1) * 178)
        
        if(i==3) 
             {
               createjs.Tween.get(introQuesArr1[i]).wait(val)
      .to({ x:  450 + ((i - 1) * 188) ,alpha:1}, 500).call(handleComplete3_2)
             }
             else
             {
                         createjs.Tween.get(introQuesArr1[i]).wait(val)
      .to({ x:  450 + ((i - 1) * 188) ,alpha:1}, 500)
             }
             val=val+50
    }
  
}
function handleComplete3_2()
{
     if (stopValue == 0) {
        removeGameIntro()

    }
    else {
    createjs.Tween.removeAllTweens();
    ChoiceTween()
    }
}
function ChoiceTween()
{
var val1 = 150
    for (i = 1; i <= 3; i++) { 
introChoice1TweenArr[i].visible = true;
introChoice1TweenArr[i].alpha=1
introChoice1TweenArr[i].x = introbtnx1[i - 1];
     introChoice1TweenArr[i].scaleX = introChoice1TweenArr[i].scaleY = .9; 
        if (i == 3) {
            createjs.Tween.get(introChoice1TweenArr[i]).wait(val1)
                .to({ visible: true, rotation: 270, x: introbtnx[i - 1], alpha: 1 }, 500)
                .to({ visible: true, rotation: 360, x: introbtnx[i - 1], alpha: 1 }, 500).call(handleComplete3_3)
        }
        else {
            createjs.Tween.get(introChoice1TweenArr[i]).wait(val1)
                .to({ visible: true, rotation: 270, x: introbtnx[i - 1], alpha: 1 }, 500)
                .to({ visible: true, rotation: 360, x: introbtnx[i - 1], alpha: 1 }, 500)
        }
        val1 = val1 + 50;
 }      
      
    }
function handleComplete3_3() {
 if (stopValue == 0) {
        removeGameIntro()

    }
    else {
    createjs.Tween.removeAllTweens();
      hintTween()
    }
}
function hintTween()
{
var val=500
for (i = 1; i <=7; i++) {
  
        introHintImage[i].visible = true;
        introHintImage[i].alpha=0
        introHintImage[i].scalex = introHintImage[i].scaleY = 1      
        introHintImage[i].x = 0;
        introHintImage[i].y = 0;
        if(i==7)
        {
 createjs.Tween.get(introHintImage[i]).wait(val)
                .to({ y: 0, alpha: 1 }, 500)
                .wait(500)
                .call(handleComplete3_4)
        }
     else{
createjs.Tween.get(introHintImage[i]).wait(val)
                .to({ y: 0, alpha: 1 }, 500)
     }
     val=val+1000
    }
}
function handleComplete3_4() {
    createjs.Tween.removeAllTweens();    
for (i = 1; i <=7; i++) {  
        introHintImage[i].visible = false;
        introHintImage[i].alpha=0   
}                    
   
   if (stopValue == 0) {
        removeGameIntro()

    }
    else {
    createjs.Tween.removeAllTweens();
     introHintImage[7].visible = true;
 createjs.Tween.get(introHintImage[7])
                .to({ y: 0, alpha: 1,scaleX:.95,scaleY:.95 }, 500)
                .to({ scaleX:.9,scaleY:.9 }, 500)
                .to({scaleX:.95,scaleY:.95 }, 500).call(answerTween) 
   
}
}
function  answerTween()

{    
    var val=250
    for (i = 1; i <= 4; i++) {
        introAnswerArr[i].visible = true;
        introAnswerArr[i].alpha=0.5
        introAnswerArr[i].y=465
        
        if(i==4) 
             {
               createjs.Tween.get(introAnswerArr[i]).wait(val)
      .to({ y:470 ,alpha:1}, 500).call(handleComplete4_1)
             }
             else
             {
                         createjs.Tween.get(introAnswerArr[i]).wait(val)
      .to({ y:470,alpha:1}, 500)
             }
             val=val+500
    }
  
}


function handleComplete4_1() {
    createjs.Tween.removeAllTweens();

 if (stopValue == 0) {
        removeGameIntro()

    }
    else {    setArrowTween()
    }
}
function setArrowTween() {
    if (stopValue == 0) {
        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);
  
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])

        highlightTweenArr[0] = createjs.Tween.get(introArrow)
        .to({ y: introArrowY + 10 }, 350).to({ y: introArrowY }, 350).to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)


    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()

    }
    else {

        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;

        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200)
            .call(this.onComplete2)
        
    }
}

this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();


    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {
        console.log("///setcallDelat=====+");
        setTimeout(answerFn, 500)
    }

}

function answerFn() {
 createjs.Tween.get(introChoice1TweenArr[2]).wait(250)
                .to({ visible: true, scaleX:1, scaleY:1, alpha: 1 }, 500)
                .to({scaleX:.9, scaleY:.9, alpha: 1 }, 500);
    introAnswerArr[2].visible=true  
    introAnswerArr[2].alpha=1
    introAnswerArr[2].gotoAndStop(2)
createjs.Tween.get(introAnswerArr[2]).wait(1500)
                .to({  alpha: 1 }, 500)               
        .call(setCallDelay)
}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    removeGameIntro()
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}

function removeGameIntro() {
    createjs.Tween.removeAllTweens();
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false


    container.parent.removeChild(introQuestionText)
    introQuestionText.visible = false

    for (i = 1; i <= 3; i++) {
           introQuesArr[i].visible = false;
    container.parent.removeChild(introQuesArr[i])     
    } 

    for (i = 1; i <= 3; i++) {
        introQuesArr1[i].visible = false;
        container.parent.removeChild(introQuesArr1[i])    
    }
    

for (i = 1; i <=7; i++) {
      
        container.parent.removeChild(introHintImage[i]);
        introHintImage[i].visible = false;
}
    for (i = 1; i <= 4; i++) {        
        introAnswerArr[i].visible = false;
        container.parent.removeChild(introAnswerArr[i])
    }
    for (i = 1; i <= 3; i++) {     
        introChoice1TweenArr[i].visible = false;
        container.parent.removeChild( introChoice1TweenArr[i])
    }
    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }
}