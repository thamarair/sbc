
//////////////////////////////////////////////////////===========COMMON GAME VARIABLES==========/////////////////////////////////////////////////////////////
var messageField;		//Message display field
var assets = [];
var assetsPath, gameAssetsPath, soundpath, bg;
var cnt = -1, qscnt = -1, ans, uans, interval, time = 180, totalQuestions = 10, answeredQuestions = 0, choiceCnt = 30, quesCnt = 0, resTimerOut = 0, rst = 0, responseTime = 0;
var startBtn, introScrn, container, question, boardMc, helpMc, quesMarkMc, questionText, resultLoading, preloadMc;
var startMc, questionInterval = 0, chHolderMc = 0, Holder;
var parrotWowMc, parrotOopsMc, parrotGameOverMc, parrotTimeOverMc;
var bgSnd, correctSnd, wrongSnd, gameOverSnd, timeOverSnd, tickSnd;
var tqcnt = 0, aqcnt = 0, ccnt = 0, cqcnt = 0, gscore = 0, gscrper = 0, gtime = 0, rtime = 0, crtime = 0, wrtime = 0, currTime = 0;
var rst1 = 0, crst = 0, wrst = 0, score = 0, puzzle_cycle, timeOver_Status = 0;//for db //q
var isBgSound = true;
var isEffSound = true;
var url = "";
var nav = "";
var isResp = true;
var respDim = 'both'
var isScale = true
var scaleType = 1;
var lastW, lastH, lastS = 1;
var borderPadding = 10, barHeight = 20;
var loadProgressLabel, progresPrecentage, loaderWidth;

////////////////////////////////////////////////////==========GAME SPECIFIC VARIABLES============/////////////////////////////////////////////////////////////
var bg1;

//////////////////////////////////////////////////////==========GAME SPECIFIC ARRAYS============/////////////////////////////////////////////////////////////
var qno = [];
var choiceArr = []
var tweenMcArr = []
var posx = [140, 535, 675, 845, 30, 350, 510, 895, 200, 15, 530, 250, 800, 430, 660]
var posy = [190, 180, 245, 225, 325, 235, 295, 355, 310, 500, 510, 455, 480, 410, 380]
// var posx = [230, 460, 580, 705, 135, 350, 460, 740, 270, 95, 265, 520, 605, 200, 355]
// var posy = [170, 145, 260, 250, 270, 240, 295, 355, 325, 395, 500, 385, 475, 425, 425]
var posi = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
/////////////////////////////////////////////////////////=========BROWSER SUPPORT============////////////////////////////////////////////////////////////////
//register key functions
window.onload = function (e) {
    checkBrowserSupport();
}
//////////////////////////////////////////////////////////=========INITIALIZATION=============///////////////////////////////////////////////////////////////
function init() {
    console.log("innt")

    canvas = document.getElementById("gameCanvas");
    stage = new createjs.Stage(canvas);
    container = new createjs.Container();
    stage.addChild(container)
    createjs.Ticker.addEventListener("tick", stage);

    callLoader();
    createLoader();
    createCanvasResize()

    stage.update();
    stage.enableMouseOver(40);
    ///////////////////////////////////////////////////////////////=========MANIFEST==========///////////////////////////////////////////////////////////////

    /*Always specify the following terms as given in manifest array. 
         1. choice image name as "ChoiceImages1.png"
         2. question text image name as "questiontext.png"
     */

    assetsPath = "assets/";
    gameAssetsPath = "NotAPair-Level1/";
    soundpath = "FA/"

    var success = createManifest();
    if (success == 1) {
        manifest.push(
            { id: "Holder", src: gameAssetsPath + "Holder.png" },
            {id: "introHint",src:gameAssetsPath + "Introhintimg1.png"},
            {id: "introHint1",src:gameAssetsPath + "Introhintimg1.png"},
            { id: "choice1", src: gameAssetsPath + "choiceImages1.png" },
            { id: "questionText", src: questionTextPath + "NotAPair-Level1-QT.png" }

        )
        preloadAllAssets()
        stage.update();
    }
}

////////////////////////////////////////////////////////////==========PRELOADER===========////////////////////////////////////////////////////////////////      
function doneLoading1(event) {
    var event = assets[i];
    var id = event.item.id;

    if (id == "Holder") {
        Holder = new createjs.Bitmap(preload.getResult('Holder'));
        container.parent.addChild(Holder);
        Holder.visible = false;
    }
    if (id == "introHint") {
        introHint = new createjs.Bitmap(preload.getResult('introHint'));
        container.parent.addChild(introHint);
        introHint.visible = false;
    }
 
     if (id == "introHint1") {
        introHint1 = new createjs.Bitmap(preload.getResult('introHint1'));
        container.parent.addChild(introHint1);
        introHint1.visible = false;
    }

    if (id == "questionText") {
        questionText = new createjs.Bitmap(preload.getResult('questionText'));
        container.parent.addChild(questionText);
        questionText.visible = false
    }

    if (id == "choice1") {
        var spriteSheet2 = new createjs.SpriteSheet({
            framerate: 30,
            "images": [preload.getResult("choice1")],
            "frames": { "regX": 50, "height": 164, "count": 0, "regY": 50, "width": 195 },
            // define two animations, run (loops, 1.5x speed) and jump (returns to run):

        });
        choice1 = new createjs.Sprite(spriteSheet2);
        choice1.visible = false;
        container.parent.addChild(choice1);
        choice1.x = 400; choice1.y = 400;
    };


}
function tick(e) {
    stage.update();
}

/////////////////////////////////////////////////////////////////=======GAME START========///////////////////////////////////////////////////////////////////
function handleClick(e) {
     qno = between(0, 49); 
     qno.sort(randomSort)
     console.log(qno);
    CreateGameStart()
    if (gameType == 0) {
        CreateGameElements()
        getStartQuestion();
    } else {
        //for db
        getdomainpath()
        //end
    }
}


////////////////////////////////////////////////////////////=========GAME ELEMENTS CREATION===========//////////////////////////////////////////////////////
function CreateGameElements() {
    container.parent.addChild(questionText)
    questionText.visible = false;
    container.parent.addChild(Holder)
    Holder.visible = false;
    Holder.y = 0
    Holder.x = 0

    for (i = 0; i < 15; i++) {
        choiceArr[i] = choice1.clone();
        container.parent.addChild(choiceArr[i])
        choiceArr[i].visible = false;
        choiceArr[i].x = posx[i] -500
        choiceArr[i].y = posy[i] + 20 + 90
        
    }
}
function helpDisable() {
    for (i = 0; i < 15; i++) {
        choiceArr[pos[i]].mouseEnabled = false;
    }
}
function helpEnable() {
    for (i = 0; i < 15; i++) {
        choiceArr[pos[i]].mouseEnabled = true;
    }
}
//=================================================================================================================================//
function pickques() {
    pauseTimer();
    clk = 0
    cnt++;
    qscnt++;
    quesCnt++;
    var j = 0;
    panelVisibleFn();
   var posi=between(0,14)
   console.log("posi"+posi)
    posi.sort(randomSort)
    qno = between(0, 49)
    tx = 0;
    console.log(posi)
    for (i = 0; i < 14; i++) {
        if (i < 7) {
            console.log(posi[i] + "position");
            console.log("count" + qno[i]);
            choiceArr[posi[i]].gotoAndStop(qno[i])
            choiceArr[posi[i]].name = qno[i]
            choiceArr[posi[i]].visible = false
            choiceArr[posi[i]].alpha = 1
        }
        else {

            choiceArr[posi[i]].gotoAndStop(qno[j])
            choiceArr[posi[i]].name = qno[j + 8]
            choiceArr[posi[i]].visible = false
            choiceArr[posi[i]].alpha = 1
            j++;
        }
    
    }
    choiceArr[posi[14]].gotoAndStop(qno[7])
    choiceArr[posi[14]].name = qno[7]
    choiceArr[posi[14]].visible = false
    choiceArr[posi[14]].alpha = 1
console.log(  choiceArr[posi[14]]+"choice answer")
    ans = qno[7];
console.log( ans+"Answer")
    createTween();
    createjs.Ticker.addEventListener("tick", tick);
    stage.update();
}

function createTween() {
    questionText.visible = true;
    questionText.alpha = 0;
    questionText.x = -290
    questionText.y = 0
    createjs.Tween.get(questionText).wait(100).to({ x: 0, alpha: 1 }, 400);

    Holder.visible = false;
    Holder.alpha = 0;
    Holder.y = Holder.y 
    Holder.x = -210  
    createjs.Tween.get(Holder).wait(500).to({ x: 0, alpha: 1 }, 400);

    var temval = 900;
    for (i = 0; i < 15; i++) {
        choiceArr[posi[i]].visible = true;
        choiceArr[posi[i]].alpha = 0
        choiceArr[posi[i]].scaleX = choiceArr[i].scaleY = .65
        choiceArr[i].x = posx[i] -500
        choiceArr[i].y = posy[i] + 55
      
        if (i == 14) {
            createjs.Tween.get(choiceArr[posi[i]]).wait(temval)
                .to({ x: posx[i] +170, alpha: 1, scaleX: .65, scaleY: .65 }, 500).wait(500)
        }
        else {
            createjs.Tween.get(choiceArr[posi[i]]).wait(temval)
                .to({ x: posx[i] +170,  alpha: 1, scaleX:.65, scaleY: .65 }, 500)
        }
  
        temval = temval + 100
    }
 
    repTimeClearInterval = setTimeout(AddListenerFn, 3000)
}
/////////////////////////////////////////////////////////========CHOICES ENABLE/DISABLE=======////////////////////////////////////////////////////////////
function AddListenerFn() {
    clearTimeout(repTimeClearInterval)
      for (i = 0; i < 15; i++) {
        choiceArr[posi[i]].addEventListener("click", answerSelected);
        choiceArr[posi[i]].cursor = "pointer";
        choiceArr[posi[i]].mouseEnabled = true;
    }
    rst = 0;
    gameResponseTimerStart();
    restartTimer()
}
function disablechoices() {
    for (i = 0; i < 15; i++) {
        choiceArr[posi[i]].removeEventListener("click", answerSelected);
        choiceArr[posi[i]].visible = false;
        choiceArr[posi[i]].cursor = "default";
        choiceArr[posi[i]].mouseEnabled = false;

    }
}
function answerSelected(e) {
    e.preventDefault();
    uans = e.currentTarget.name;
    console.log("answer" + uans);
    gameResponseTimerStop();

    if (uans == ans) {
        getValidation("correct");
    } else {
        getValidation("wrong");
    }
    disablechoices();

}
