var introQues1, introTitle, introQuestxt, introHolder, introArrow, introfingure;
var introCircle = [], introCircle1 = []
var introChoice = []
var highlightTweenArr = []
var setIntroCnt = 0
var removeIntraval = 0
var introArrowX = 1071, introArrowY = 340;
var introfingureX = 1083, introfingureY = 448;

var Imgx = [140, 535, 675, 845, 30, 350, 510, 895, 200, 15, 530, 250, 800, 430, 660]
var Imgy = [190, 180, 245, 225, 325, 235, 295, 355, 310, 500, 510, 455, 480, 410, 380]
//var Imgx = [240, 550, 680, 835, 125, 400, 540, 885, 275, 55, 335, 205, 735, 430, 595]
//var Imgy = [170, 170, 245, 245, 260, 235, 295, 355, 320, 385, 518, 435, 475, 412, 410]
// var cirX = [380,260,580,780,1075,910,750];
// var cirX1=[430,1050,650,260,475,770,910]
// var cirY = [225,360,285,225,280,290,350];
// var cirY1=[375,520,455,540,500,565,440]

var cirX = [380,268,588,775,1083,912,749];
var cirX1=[438,1040,668,255,487,769,899]
var cirY = [233,367,280,218,269,289,344];
var cirY1=[353,522,452,542,496,556,424]
function commongameintro() {

    introTitle = Title.clone();
    introTitle.visible = true;
    container.parent.addChild(introTitle)

    introQuestxt = questionText.clone()
    introHolder = Holder.clone()
    introArrow = arrow1.clone()
    introfingure = fingure.clone()
    introCircle = introHint.clone();
    container.parent.addChild(introHolder)
    introHolder.visible = false;
    introHolder.y = 0
    introHolder.x = -210
    container.parent.addChild(introQuestxt)
    introQuestxt.visible = true;

    for (i = 1; i <= 15; i++) {
        introChoice[i] = choice1.clone();
        container.parent.addChild(introChoice[i])
        introChoice[i].visible = false;
        introChoice[i].gotoAndStop(i - 1)
        introChoice[i].alpha = 0
        introChoice[i].scaleX = introChoice[i].scaleY = 1

    }
    for (i = 1; i <= 7; i++) {
         introCircle[i] = introHint.clone();
        container.parent.addChild(introCircle[i])
        introCircle[i].visible = false
        introCircle[i].x = cirX[i-1]-100
        introCircle[i].y = cirY[i-1]
    }
    for (i = 1; i <= 7; i++) {
        introCircle1[i] = introHint1.clone();
        container.parent.addChild(introCircle1[i])
        introCircle1[i].visible = false
        introCircle1[i].x = cirX1[i-1]-100
        introCircle1[i].y = cirY1[i-1]
    }

    introQuestxt.alpha = 0;
    introQuestxt.x = -290
    introQuestxt.y = 0
    createjs.Tween.get(introQuestxt).wait(500)
        .to({ x: 0, alpha: 1 }, 500).call(handleComplete1_1);


}
function handleComplete1_1() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        HolderTween()
    }
}

function HolderTween() {
    introHolder.visible = false
    introHolder.alpha = 0;
    introHolder.x = -210
    introHolder.y = 25
    createjs.Tween.get(introHolder).wait(500)
        .to({ alpha: 1, y: 25, x: 0 }, 500)
        .call(handleComplete1_2);

}
function handleComplete1_2() {
    createjs.Tween.removeAllTweens();
    if (stopValue == 0) {
        removeGameIntro()
    }
    else {
        choiceTween()
    }
}
function choiceTween() {
    var val = 250
    var j = 1
    for (i = 1; i <= 15; i++) {
        introChoice[i].visible = true
        introChoice[i].alpha = 0
        introChoice[i].x = Imgx[i - 1] - 500
        introChoice[i].y = Imgy[i - 1] + 85
        introChoice[8].gotoAndStop(20)
        introChoice[8].alpha = 0

        if (i < 8) {
            introChoice[i].gotoAndStop(i - 1)
        }
        else if (i > 8) {
            introChoice[i].gotoAndStop(j - 1)
            j++
        }

        if (i == 15) {
            createjs.Tween.get(introChoice[i]).wait(val)
                .to({ x: Imgx[i - 1] + 170, alpha: 1, scaleX:.65, scaleY: .65 }, 500).wait(1000)
                .call(handleComplete3_1)
        }
        else {
            createjs.Tween.get(introChoice[i]).wait(val)
                .to({ x: Imgx[i - 1] + 170, alpha: 1, scaleX: .65, scaleY: .65 }, 500)
        }
        val = val + 100
    }
  }
function handleComplete3_1() {
    createjs.Tween.removeAllTweens();
    HintTween()
}
function HintTween() {

var val=200
 for (i = 1; i <= 7; i++) {

        if(i==7)
        {

  createjs.Tween.get(introCircle[7]).wait(val)
        .to({ visible: true, alpha: 1, scaleX: 1, scaleY: 1 }, 500)

createjs.Tween.get(introCircle1[7]).wait(val)
        .to({ visible: true, alpha: 1, scaleX: 1, scaleY: 1 }, 500).wait(1000)
 .call(handleComplete3_2)

        }
        
        else {
            
  createjs.Tween.get(introCircle[i]).wait(val)
        .to({ visible: true, alpha: 1, scaleX: 1, scaleY: 1 }, 500)
          
  createjs.Tween.get(introCircle1[i]).wait(val)
        .to({ visible: true, alpha: 1, scaleX: 1, scaleY: 1 }, 500)    
        }
      

      val=val+1000

    }
}
function handleComplete3_2() {
    createjs.Tween.removeAllTweens();
    for (i = 1; i <= 7; i++) {
        introCircle[i].visible = false;      
        introCircle1[i].visible = false;
    }
        
    answerTween()
}
function answerTween() {

    createjs.Tween.get(introChoice[8])
        .to({ visible: true, alpha: 1, scaleX: .65, scaleY: .65 }, 500)
        .to({ scaleX: .7, scaleY: .7 }, 500)
        .to({ scaleX: .65, scaleY: .65 }, 500)
        .to({ scaleX: .7, scaleY: .7 }, 500)
        .to({ scaleX: .65, scaleY: .65 }, 500)
        .call(handleComplete3_3)
}

function handleComplete3_3() {
    createjs.Tween.removeAllTweens();
    setTimeout(setArrowTween, 500)
}
function setArrowTween() {

    if (stopValue == 0) {

        removeGameIntro()

    }
    else {
        container.parent.addChild(introArrow);
        introArrow.visible = true;
        introArrow.x = introArrowX;
        introArrow.y = introArrowY;
        highlightTweenArr[0] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[0])
        highlightTweenArr[0] = createjs.Tween.get(introArrow)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .to({ y: introArrowY + 10 }, 350)
            .to({ y: introArrowY }, 350)
            .wait(400)
            .call(this.onComplete1)

    }
}

function setFingureTween() {
    if (stopValue == 0) {
        console.log("setFingureTween  == stopValue")
        removeGameIntro()
    }
    else {
        container.parent.removeChild(introArrow);
        introArrow.visible = false;
        container.parent.addChild(introfingure);
        introfingure.visible = true;
        introfingure.x = introfingureX;
        introfingure.y = introfingureY;
        highlightTweenArr[1] = new createjs.MovieClip()
        container.parent.addChild(highlightTweenArr[1])
        highlightTweenArr[1] = createjs.Tween.get(introfingure)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .to({ x: introfingureX }, 350)
            .to({ x: introfingureX - 15 }, 350)
            .wait(200).call(this.onComplete2)

    }
}
this.onComplete1 = function (e) {
    createjs.Tween.removeAllTweens();

    if (highlightTweenArr[0]) {
        console.log("onComplete1")
        container.parent.removeChild(highlightTweenArr[0]);
    }

    container.parent.removeChild(introArrow);
    if (stopValue == 0) {
        console.log("onComplete1  == stopValue")
        removeGameIntro()

    } else {
        setTimeout(setFingureTween, 200)
    }
}

this.onComplete2 = function (e) {
    createjs.Tween.removeAllTweens();


    if (highlightTweenArr[1]) {
        console.log("onComplete2")
        container.parent.removeChild(highlightTweenArr[1]);
    }

    container.parent.removeChild(introfingure);
    introfingure.visible = false;

    if (stopValue == 0) {
        console.log("onComplete2  == stopValue")
        removeGameIntro()

    }
    else {

        setTimeout(setCallDelay, 250)
    }

}
function setCallDelay() {
    clearInterval(removeIntraval)
    removeIntraval = 0
    setIntroCnt++
    console.log("check cnt = " + setIntroCnt)
    removeGameIntro()
    if (stopValue == 0) {
        console.log("setCallDelay  == stopValue")
        removeGameIntro()
    }
    else {
        commongameintro()
        if (setIntroCnt > 0) {
            isVisibleStartBtn()
        }
    }

}
function removeGameIntro() {

    createjs.Tween.removeAllTweens();
    // container.parent.removeChild(introTitle)
    // introTitle.visible = false
    container.parent.removeChild(introArrow)
    introArrow.visible = false
    container.parent.removeChild(introfingure)
    introfingure.visible = false

    container.parent.removeChild(introQuestxt)
    introQuestxt.visible = false
    for (i = 1; i <= 15; i++) {
        container.parent.removeChild(introChoice[i])
        introChoice[i].visible = false

    }

    for (i = 1; i <= 7; i++) {
        container.parent.removeChild(introCircle[i])
        introCircle[i].visible = false
        container.parent.removeChild(introCircle1[i])
        introCircle1[i].visible = false
    }

    container.parent.removeChild(introHolder)
    introHolder.visible = false;

    if (highlightTweenArr[0]) {
        highlightTweenArr[0].setPaused(false);
        container.parent.removeChild(highlightTweenArr[0]);
    }
    if (highlightTweenArr[1]) {
        highlightTweenArr[1].setPaused(false);
        container.parent.removeChild(highlightTweenArr[1]);
    }

}